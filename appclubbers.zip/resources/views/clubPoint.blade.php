@extends('layout.master')

@section('content')
    <div class="container-fluid">
            <div class="row">
                <div class="col s12 m12 offset-l1 l10 background-base">

                    <div class="row">

                        <div class="col s12 offset-m3 m6 l3 z-depth-1">
                            <div class="row hide-on-med-and-down text-center">
                                <h2>{{ $club->name }}</h2>
                                <hr>
                            </div>
                            <nav id="nav-clubpoint" class="pink">
                                <div class="nav-wrapper">
                                    <a href="/" class="brand-logo hide-on-large-only">
                                        <h5 class="animated swing">Menu {{ $club->name }}</h5>
                                    </a>
                                    <a href="#" data-activates="mobile-menu" class="button-collapse"><i class="material-icons">menu</i></a>
                                    <ul class="right hide-on-med-and-down animated swing">
                                        <li class="prueba test1 active"><a href="#test1">{{ trans('custom.navUserHome') }}</a></li>
                                        <br>
                                        <li class="prueba test2"><a href="#test2">{{ trans('custom.navUserEvent') }}</a></li>
                                        <br>
                                        <li class="prueba test3"><a href="#test3">{{ trans('custom.navUserReservation') }}</a></li>
                                        <br>
                                        <li class="prueba test4"><a href="#test4">{{ trans('custom.navUserContact') }}</a></li>
                                    </ul>
                                    <ul class="side-nav" id="mobile-menu">
                                        <li class="test1 active"><a href="#test1">{{ trans('custom.navUserHome') }}</a></li>
                                        <li class="test2"><a href="#test2">{{ trans('custom.navUserEvent') }}</a></li>
                                        <li class="test3"><a href="#test3">{{ trans('custom.navUserReservation') }}</a></li>
                                        <li class="test4"><a href="#test4">{{ trans('custom.navUserContact') }}</a></li>
                                    </ul>
                                </div>
                            </nav>
                            <div class="row text-center hide-on-med-and-down">
                                <br>
                                <img style="width: 60px;" src="/assets/img/isotipo.svg">
                            </div>
                        </div>

                        <div class="col s11 m11 l9 tab-conten">

                            <div id="test1" class="col s12 tab-conten-point">
                                <div class="row text-center">
                                    <h4 class="pink-text animated fadeInLeftBig">{{ $club->name }}</h4>
                                    <div class="col s12 offset-m3 m6">
                                        <img class="responsive-img animated bounceInUp" src="/storage/{{ $club->logo }}" alt="{{ $club->name }}">
                                    </div>
                                </div>
                                <div class="row">
                                    <h3 class="pink-text animated fadeInDown">{{ trans('custom.titleClubPoint') }}</h3>
                                    <hr>
                                    <p class="animated fadeInDownBig">{{ $club->description }}</p>
                                </div>
                                <div class="row">
                                    <h3 class="pink-text animated fadeInUp">{{ trans('custom.owner') }}</h3>
                                    <hr>
                                    <div class="col s12 animated fadeInRightBig">
                                            <div class="card-panel grey lighten-5 z-depth-1">
                                                <div class="row valign-wrapper">
                                                    <div class="col s12 m2 hide-on-med-and-down">
                                                        <img src="{{ $user->photo ? '/storage/'.$user->photo : '/assets/img/isotipo.svg' }}" class="circle responsive-img img-photo-club-point"> <!-- notice the "circle" class -->
                                                    </div>
                                                    <div class="col s12 m10">
                                                    <span class="black-text">
                                                        <p><strong>{{ trans('custom.ownerManager') }}</strong> {{ $user->first_name }} {{ $user->last_name }}.</p>
                                                        <p><strong>{{ trans('custom.email') }}</strong> {{ $user->email }}</p>
                                                        <p><strong>{{ trans('custom.number') }}</strong> {{ $user->contactUser->number }}</p>
                                                        <p><strong>{{ trans('custom.cell') }}</strong> {{ $user->contactUser->cell }}</p>
                                                        <p><strong>Facebook</strong> {{ $user->contactUser->facebook }}</p>
                                                        <p><strong>Twitter</strong> {{ $user->contactUser->twitter }}</p>
                                                    </span>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                </div>
                                @include('forms.formMessage')
                            </div> {{-- INICIO --}}
                            <div id="test2" class="col s12 tab-conten-point hidden">

                                <div class="row text-center">
                                    <h4 class="animated bounceInLeft">{{ trans('custom.titleClubPointEvent') }}</h4>
                                </div>

                                <div>
                                    @if($flagEvent)
                                        @foreach($club->eventEstablishments as $event)
                                            <div class="row grey lighten-5 z-depth-1">
                                                <div class="col s12 m12 l5">
                                                    <h3 class="pink-text animated slideInUp">{{ trans('custom.titleInvitation') }}</h3>
                                                    <p class="animated slideInUp">{{ $event->description }}</p>
                                                </div>
                                                <div class="col s12 m12 l7">
                                                    <div class="row">
                                                        <div class="col s12">
                                                            <h5 class="pink-text animated slideInUp">{{ $event->name }}</h5>
                                                        </div>
                                                        <div class="col s12 m4">
                                                            <img class="materialboxed responsive-img" src="/storage/{{ $event->poster }}" alt="{{ $event->poster }}">
                                                        </div>
                                                        <div class="col s12 m8">
                                                            <p><i class="material-icons">room</i> <a href="{{ route('searchClubMap',$club->lat.'&'.$club->lng) }}">{{ trans('custom.linkMap') }}</a></p>
                                                            <p><i class="material-icons">event</i> {{ $event->date_in }}</p>
                                                            <p><i class="material-icons">attach_money</i> {{ $event->price }}</p>
                                                        </div>
                                                        <strong>{{ trans('custom.shared') }}</strong>
                                                        <div class="col 12 animated slideInUp">
                                                            <div class="col s12 text-center">
                                                                <a href="https://www.facebook.com/sharer/sharer.php?u=http%3A%2F%2Fappclubbers.com%2Fclubs%2F1%23test2" class="btn waves waves-effect blue darken-4 btn-sm">Facebook</a>
                                                                <button class="btn waves waves-effect blue accent-3 btn-sm">Twitter</button>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                                <div class="col s12 text-center white  animated slideInUp">
                                                    <br>
                                                    <a class="btn waves waves-effect green accent-4" href="#">{{ trans('custom.btnShop') }}</a>
                                                    <br><br>
                                                </div>
                                            </div>
                                        @endforeach
                                    @else
                                        <h1>no hay nada que mostrar</h1>
                                    @endif
                                </div>

                            </div> {{-- EVENTOS --}}

                            <div id="test3" class="col s12 tab-conten-point hidden">
                                En construccion
                            </div> {{-- Reservaciones --}}

                            <div id="test4" class="col s12 tab-conten-point hidden">
                                <div class="row center-align">
                                    <h4>{{ trans('custom.titleClubPointContact') }}</h4>
                                    <hr>
                                </div>
                                <div class="row">
                                    <div class="col s12">
                                        <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aliquam asperiores at atque distinctio esse. Assumenda, autem beatae blanditiis dolorem error ex explicabo facere iure laborum, maxime, molestias necessitatibus recusandae ullam.</p>
                                    </div>
                                    <div class="col s12 m7">
                                        @include('forms.formMessage')
                                    </div>
                                    <div class="col s12 m5">
                                        <div class="row">
                                            <h3 class="pink-text">{{ trans('custom.owner') }}</h3>
                                            <hr>
                                        </div>
                                        <div class="row">
                                            <div class="col s12 animated bounceInUp">
                                                <p><strong>{{ trans('custom.ownerManager') }}</strong> {{ $user->first_name }} {{ $user->last_name }}.</p>
                                                <p><strong>{{ trans('custom.email') }}</strong> {{ $user->email }}</p>
                                                <p><strong>{{ trans('custom.number') }}</strong> {{ $user->contactUser->number }}</p>
                                                <p><strong>{{ trans('custom.cell') }}</strong> {{ $user->contactUser->cell }}</p>
                                                <p><strong>Facebook: </strong>{{ $user->contactUser->facebook }}</p>
                                                <p><strong>Twitter: </strong>{{ $user->contactUser->twitter }}</p>
                                            </div>
                                        </div>
                                    </div>
                                </div>

                            </div>{{-- CONTCATOS --}}

                        </div>

                    </div>

                </div>
            </div>
    </div>
@endsection
