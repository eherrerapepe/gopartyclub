<div class="row">
    <h4>{{ trans('custom.titleFormBasicDatesEstablishment') }}</h4>
    <hr>
</div>
<div class="row">
    <div class="file-field input-field col s12 m6">
        <div class="btn pink">
            <span>{{ trans('custom.btnLogo') }}</span>
            {!! Form::file('logo') !!}
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" name="logo" type="text">
        </div>
    </div>
    <div class="input-field col s12 m6">
        {!! Form::text('name',null,['class'=>'validate']) !!}
        {!! Form::label('nombre',trans('custom.inputNameEstablishment')) !!}
    </div>
</div>
<div class="row">
    <div class="input-field col s12">
        {!! Form::textarea('description',null,['class'=>'materialize-textarea','length'=>'400']) !!}
        {!! Form::label('descripcion',trans('custom.inputMessageWelcome')) !!}
    </div>
</div>
<div class="row">
    <div class="input-field col s12 m6">
        {!! Form::select('type',['Bar'=>'Bar','Karaoke'=>'Karaoke','Discoteca'=>'Discoteca']) !!}
        {!! Form::label('tipo', trans('custom.inputType')) !!}
    </div>
    <div class="input-field col s12 m6">
        {!! Form::number('capacity',null,['min'=>'0']) !!}
        {!! Form::label('capacidad',trans('custom.inputCapacity')) !!}
    </div>
</div>

<div class="row">
    <h4>{{ trans('custom.titleFormContact') }}</h4>
    <hr>
</div>

<div class="row">
    <div class="input-field col s12 m6">
        {!! Form::email('email',null) !!}
        {!! Form::label('e-opcional', trans('custom.inputEmail')) !!}
    </div>
    <div class="input-field col s12 m6">
        {!! Form::text('web',null) !!}
        {!! Form::label('sitio-web',trans('custom.inputSiteWeb')) !!}
    </div>
</div>
<div class="row">
    <div class="input-field col s12 m6">
        {!! Form::text('phono',null) !!}
        {!! Form::label('convencional',trans('custom.inputFormNumber')) !!}
    </div>
    <div class="input-field col s12 m6">
        {!! Form::text('cell',null) !!}
        {!! Form::label('celular',trans('custom.inputFormCell')) !!}
    </div>
</div>

<div class="row">
    <h4>{{ trans('custom.titleAddFormFanPages') }}</h4>
    <hr>
</div>
<div class="row">
    <div class="input-field col s12">
        {!! Form::text('facebook',null) !!}
        {!! Form::label('facebook',trans('custom.inputFanPageFacebook')) !!}
    </div>
</div>
<div class="row">
    <div class="input-field col s12 m6">
        {!! Form::text('twitter',null) !!}
        {!! Form::label('instagram',trans('custom.inputFanPageTwitter')) !!}
    </div>
    <div class="input-field col s12 m6">
        {!! Form::text('instagram',null) !!}
        {!! Form::label('instagram',trans('custom.inputFanPageInstagram')) !!}
    </div>
</div>

<div class="row">
    <h4>{{ trans('custom.titleCurrentForm') }}</h4>
    <hr>
</div>
<div class="row">
    <p>{{ trans('custom.leyendaCurrency') }}</p>
</div>
<div class="row">
    <div class="input-field col s12 offset-m3 m6">
        {!! Form::select('currency',['USD'=>'Dólares','COP'=>'Pesos Colombianos','MX'=>'Pesos Mexicanos']) !!}
        {!! Form::label('moneda',trans('custom.inputCurrent')) !!}
    </div>
</div>