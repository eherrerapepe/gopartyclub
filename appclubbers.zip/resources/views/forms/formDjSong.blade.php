<div class="row">
    <h4>{{ trans('custom.formTitleDj') }}</h4>
    <hr>
</div>
<div class="row">
    <div class="input-field col s12">
        {!! Form::text('title',null,['class'=>'validate','placeholder'=> trans('custom.titleViewInPresentation')]) !!}
        {!! Form::label('title',trans('custom.titleMezcla')) !!}
    </div>
</div>
<div class="row">

    <div class="file-field input-field col s12 m6">
        <div class="btn waves waves-effect pink">
            <span>{{ trans('custom.tableDisc') }}</span>
            <input type="file" name="disco">
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" type="text" name="disco" placeholder="{{ trans('custom.placeholderDisco') }}">
        </div>
    </div>
    <div class="file-field input-field col s12 m6">
        <div class="btn waves waves-effect pink">
            <span>{{ trans('custom.tableSong') }}</span>
            <input type="file" name="song">
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" type="text" name="song" placeholder="{{  trans('custom.placeholderMezcla') }}">
        </div>
    </div>


    <input type="hidden" value="{{ date('Y-m-d') }}" name="date_time">
    <input type="hidden" value="{{ Auth::user()->id }}" name="user_id">
</div>