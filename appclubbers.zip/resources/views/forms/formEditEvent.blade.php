<div class="row">
    <h4>{{ trans('custom.titleEventFormAdd') }}</h4>
    <hr>
</div>
<div class="row">
    <div class="input-field col s12 m6">
        <select class="icons" name="event[establishment_id]">
            <option disabled selected>{{ trans('custom.titleSelectEventInto') }}</option>
            @foreach($establishments as $establishment)
                <option value="{{ $establishment->id }}" {{ $event->establishment_id == $establishment->id ? 'selected' : '' }} data-icon="/storage/{{ $establishment->logo }}" class="left circle">{{ $establishment->name }}</option>
            @endforeach
        </select>
        <label>{{ trans('custom.titleOptionEstablishment') }}</label>
    </div>
    <div class="input-field col s12 m6">
        <input type="text" name="event[name]" class="validate" value="{{ $event->name }}">
        {!! Form::label('nombre',trans('custom.titleNameEvent')) !!}
    </div>
</div>
<div class="row">
    <div class="input-field col s12">
        <textarea name="event[description]" class="materialize-textarea" cols="30" rows="10" length="400">{{ $event->description }}</textarea>
        {!! Form::label('descripcion',trans('custom.descriptionAddEvent')) !!}
    </div>
</div>
<div class="row">
    <div class="file-field input-field col s12 m6">
        <div class="btn pink">
            <span>{{ trans('custom.btnPublicity') }}</span>
            <input type="file" name="poster">
        </div>
        <div class="file-path-wrapper">
            <input class="file-path validate" name="poster" type="text" placeholder="{{ trans('custom.placeholderPublicity') }}">
        </div>
    </div>
    <div class="input-field col s12 m6">
        <input type="text" id="date-format" name="event[date_in]" class="form-control floating-label" placeholder="{{ trans('custom.formatDateTime') }}" value="{{ $event->date_in }}">
        <label for="date_in">{{ trans('custom.titleDateEvent') }}</label>
    </div>
</div>
<div class="row">
    <div class="input-field col s12 m6">
        <input id="price" name="event[price]" type="text" class="validate" value="{{ $event->price }}">
        <label for="price">{{ trans('custom.valueInto') }}</label>
    </div>
</div>
