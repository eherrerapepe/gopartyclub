<div class="row">
    <h3 class="pink-text">{{ trans('custom.formContact') }}</h3>
    <hr>
    {!! Form::open(['route'=>'mail.store','method'=>'POST']) !!}
    <input type="hidden" value="{{ $user->email }}" name="club_mail">
    <div class="row">
        <div class="input-field col s12 m6 offset-m3">
            <input name="asunto" type="text" class="validate">
            <label for="asunto">{{ trans('custom.subject') }} <small class="red-text">*</small></label>
        </div>
    </div>
    <div class="row">
        <div class="input-field col s12 m6">
            <input name="name" type="text" class="validate">
            <label for="name">{{ trans('custom.name') }} <small class="red-text">*</small></label>
        </div>
        <div class="input-field col s12 m6">
            <input name="email" type="email" class="validate">
            <label for="email-contact">{{ trans('custom.email') }} <small class="red-text">*</small></label>
        </div>
    </div>
    <div class="row">
        <div class="input-field col s12">
            <textarea name="body" class="materialize-textarea" length="120"></textarea>
            <label for="body">{{ trans('custom.message') }} <small class="red-text">*</small></label>
        </div>
    </div>
    <div class="row text-center">
        <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSubmit') }}</button>
    </div>
    {!! Form::close() !!}
</div>