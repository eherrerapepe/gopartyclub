@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col s12 l8 offset-l2 text-center">
                <h4 class="animated bounceInLeft">{{ trans('custom.homeTitle') }}</h4>
                <hr>
                <div class="row">

                    <div class="col s12 m12 l4 animated bounceInLeft">
                        <br>
                        <a href="{{ route('clubs') }}"><img  class="responsive-img img-hover" src="{{ asset('assets/img/club.png') }}"></a><br>
                        <a class="btn waves waves-effect pink" href="{{ route('clubs') }}">{{ trans('custom.btnHomeClubs') }}</a>
                        <br>
                    </div>
                    <div class="col s12 m12 l4 animated bounceInLeft">
                        <br>
                        <a href="{{ route('events') }}"><img class="responsive-img img-hover" src="{{ asset('assets/img/event.png') }}"></a><br>
                        <a class="btn waves waves-effect pink" href="{{ route('events') }}">{{ trans('custom.btnHomeEvent') }}</a>
                        <br>
                    </div>
                    <div class="col s12 m12 l4 animated bounceInLeft">
                        <br>
                        <a href="{{ route('profileDj') }}"><img class="responsive-img img-hover" src="{{ asset('assets/img/dj.png') }}"></a><br>
                        <a class="btn waves waves-effect pink" href="{{ route('profileDj') }}">{{ trans('custom.btnHomeDj') }}</a>
                        <br>
                    </div>

                </div>
            </div>

            <div class="col s12 l8 offset-l2 text-center">
                <hr>
                <div class="row">
                    <div class="col s12 l6">
                        <h4 class="animated zoomInDown">{{ trans('custom.titleHomeWelcome') }}</h4>
                        <p class="text-justify animated rollIn">
                            {{ trans('custom.contentHome') }}
                        </p>
                    </div>
                    <div class="col s12 l6 animated zoomIn">
                        <div class="slider">
                            <ul class="slides">
                                <li>
                                    <img class="responsive-img" src="{{ asset('assets/img/1.png') }}"> <!-- random image -->
                                    <div class="caption center-align">
                                        <h4>This is our big Tagline!</h4>
                                        <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
                                    </div>
                                </li>
                                <li>
                                    <img class="responsive-img" src="{{ asset('assets/img/2.png') }}"> <!-- random image -->
                                    <div class="caption left-align">
                                        <h4>Left Aligned Caption</h4>
                                        <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
                                    </div>
                                </li>
                                <li>
                                    <img class="responsive-img" src="{{ asset('assets/img/3.png') }}"> <!-- random image -->
                                    <div class="caption right-align">
                                        <h4>Right Aligned Caption</h4>
                                        <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
                                    </div>
                                </li>
                                <li>
                                    <img class="responsive-img" src="{{ asset('assets/img/4.png') }}"> <!-- random image -->
                                    <div class="caption center-align">
                                        <h4>This is our big Tagline!</h4>
                                        <h5 class="light grey-text text-lighten-3">Here's our small slogan.</h5>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>

        </div>
    </div>
@endsection