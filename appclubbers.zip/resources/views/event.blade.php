@extends('layout.master')

@section('content')
    <div class="container-fluid">

        <div class="row">
            <div class="col s12 m12 offset-l1 l10 background-base">

                <div class="row text-center animated bounceInLeft">
                    <h1><span class="glyphicon glyphicon-glass"></span></h1>
                    <h4>{{ trans('custom.titleEvent') }}</h4>
                    <hr>
                </div>

                <section id="event-loading">

                    @foreach($events as $event)

                        <article class="white-panel animated fadeInUp">
                            <div class="card card-event">
                                <div class="card-image">
                                    <img class="responsive-img" src="/storage/{{ $event->poster }}">
                                    <span class="card-title">{{ $event->name_event }}</span>
                                </div>
                                <div class="card-content">
                                    <h4 class="pink-text">{{ trans('custom.titleInvitation') }}</h4>
                                    <hr>
                                    <p>{{ $event->event_description }}</p>
                                </div>
                                <div class="card-action text-center">
                                    <a class="modal-trigger waves-effect waves-light btn pink accent-3" href="#evento{{ $event->id }}">{{ trans('custom.btnDetail') }}</a>
                                    <a class="btn waves waves-effect pink" href="{{ route('clubpoint', $event->establishment_id) }}">{{ trans('custom.bntClubPoint') }}</a>
                                </div>
                            </div>
                        </article>
                    @endforeach

                </section>

                @foreach($events as $event)
                    {{-- Modales para los eventos con esta mostramos los detalles --}}
                    <div id="evento{{ $event->id }}" class="modal modal-fixed-footer">
                        <div class="modal-content">
                            <div class="row">
                                <div class="col s12">
                                    <h4 class="title-primary pink-text">{{ $event->name_event }}</h4>
                                </div>
                                <div class="col s12 m6">
                                    <img class="responsive-img" src="/storage/{{ $event->poster }}">
                                    <hr>
                                    <strong>{{ trans('custom.titleInvitation') }}</strong>
                                    <p>{{ $event->event_description }}</p>
                                    <p>
                                    <strong>{{ trans('custom.shared') }}</strong>
                                    <hr>
                                        <a class="btn blue darken-4" href="#">Facebook</a>
                                        <a class="btn light-blue" href="#">Twitter</a>
                                    </p>
                                </div>
                                <div class="col s12 m6">
                                    <div class="card-panel">
                                        <p class="text-center">
                                            <a style="font-size: 25px !important;" class="tooltipped" data-position="bottom" data-delay="50" data-tooltip="Visitar el Sitio." href="{{ route('clubpoint', $event->establishment_id) }}">
                                                <h3>{{ $event->name }}</h3>
                                            </a>
                                        </p>
                                        <p>{{ $event->type }}</p>
                                        <hr>
                                        <strong>{{ trans('custom.addressEvent') }}</strong>
                                        <p>{{ $event->address }}</p>
                                        <hr>
                                        <strong>{{ trans('custom.dateTime') }}</strong>
                                        <p>{{ $event->date_in }}</p>
                                        <hr>
                                        <strong>{{ trans('custom.valueInto') }}</strong>
                                        <p>$ {{ $event->price }} {{ $event->currency }}</p>
                                        <p><a class="btn waves waves-effect green accent-4" href="">{{ trans('custom.btnShop') }}</a></p>
                                        <hr>
                                        <strong>Ubicacion Geográfica</strong>

                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat pink-text">{{ trans('custom.btnClose') }}</a>
                        </div>
                    </div>
                @endforeach

                {{-- Paginación --}}
                <div class="col s12 offset-m1 m10 text-center">
                    {!! $events->render() !!}
                </div>

            </div>
        </div>

    </div>
@endsection