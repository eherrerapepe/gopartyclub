<footer class="page-footer red animated slideInUp">
    <div class="container center-align  white-text">
        © 2016 Copyright <a class="white-text" href="/">GoPartyClub</a>
    </div>
</footer>