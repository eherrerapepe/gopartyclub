@include('layout.drop-dow')

{{-- NAV PARA EL ADMIN --}}

@if(Auth::user()->role === 'Admin')
    @include('layout.drop-dow')

    <div class="navbar-fixed">
        <nav class="brown darken-4 white-text">
            <div class="nav-wrapper">
                <a class="brand-logo" href="/"><h4 class="white-text">Dashboard</h4></a>
                <a href="#" data-activates="mobile-demo-nav-panel" class="button-collapse"><i class="material-icons">developer_mode</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="{{ route('homeAdmin') }}"><i class="material-icons">home</i></a></li>
                    <li><a href="{{ route('admin.establishment.index') }}"><i class="material-icons">equalizer</i></a></li>
                    <li><a href="{{ route('admin.event.index') }}"><i class="material-icons">local_bar</i></a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
                <ul class="side-nav" id="mobile-demo-nav-panel">
                    <li><a href="{{ route('homeAdmin') }}">Inicio</a></li>
                    <li><a href="{{ route('admin.establishment.index') }}">Registrar Club</a></li>
                    <li><a href="{{ route('admin.event.index') }}">Crear Evento</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
            </div>
        </nav>
    </div>
@endif

{{---------------------------------------------------------------------------------}}


{{-- NAV PARA EL SUPER-ADMIN --}}

@if(Auth::user()->role === 'SuperAdmin')
    @include('layout.drop-dow')

    <div class="navbar-fixed">
        <nav class="brown darken-4 white-text">
            <div class="nav-wrapper">
                <a class="brand-logo" href="/"><h4 class="white-text">Dashboard</h4></a>
                <a href="#" data-activates="mobile-demo-nav-panel" class="button-collapse"><i class="material-icons">developer_mode</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="{{ route('homeSuperAdmin') }}">Inicio</a></li>
                    <li><a href="{{ route('adminUser') }}">Administradores</a></li>
                    <li><a href="{{ route('clientUser') }}">Clientes</a></li>
                    <li><a href="{{ route('djUser') }}">Dj</a></li>
                    <li><a href="#">Compras</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
                <ul class="side-nav" id="mobile-demo-nav-panel">
                    <li><a href="{{ route('homeSuperAdmin') }}">Inicio</a></li>
                    <li><a href="{{ route('adminUser') }}">Administradores</a></li>
                    <li><a href="{{ route('clientUser') }}">Clientes</a></li>
                    <li><a href="{{ route('djUser') }}">Dj</a></li>
                    <li><a href="#">Compras</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
            </div>
        </nav>
    </div>
@endif

{{---------------------------------------------------------------------------------}}

{{-- NAV PARA EL CLIENT --}}

@if(Auth::user()->role === 'Client')
    @include('layout.drop-dow')

    <div class="navbar-fixed">
        <nav class="brown darken-4 white-text">
            <div class="nav-wrapper">
                <a class="brand-logo" href="/"><h4 class="white-text">Dashboard</h4></a>
                <a href="#" data-activates="mobile-demo-nav-panel" class="button-collapse"><i class="material-icons">developer_mode</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="{{ route('homeClient') }}">Inicio</a></li>
                    <li><a href="{{ route('shopping') }}">Compras</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
                <ul class="side-nav" id="mobile-demo-nav-panel">
                    <li><a href="{{ route('homeSuperAdmin') }}">Inicio</a></li>
                    <li><a href="{{ route('adminUser') }}">Administradores</a></li>
                    <li><a href="{{ route('clientUser') }}">Clientes</a></li>
                    <li><a href="{{ route('djUser') }}">Dj</a></li>
                    <li><a href="#">Compras</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
            </div>
        </nav>
    </div>
@endif

{{---------------------------------------------------------------------------------}}

{{-- NAV PARA EL DJ --}}

@if(Auth::user()->role === 'Dj')
    @include('layout.drop-dow')

    <div class="navbar-fixed">
        <nav class="brown darken-4 white-text">
            <div class="nav-wrapper">
                <a href="#!" class="brand-logo"><h4 class="white-text">Dashboard</h4></a>
                <a href="#" data-activates="mobile-demo-nav-panel" class="button-collapse"><i class="material-icons">developer_mode</i></a>
                <ul class="right hide-on-med-and-down">
                    <li><a href="{{ route('homeDj') }}"><i class="material-icons">home</i></a></li>
                    <li><a href="{{ route('dj.djSong.index') }}"><i class="material-icons">library_music</i></a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
                <ul class="side-nav" id="mobile-demo-nav-panel">
                    <li><a href="{{ route('homeDj') }}">Inicio</a></li>
                    <li><a href="{{ route('dj.djSong.index') }}">Multimedia</a></li>
                    <li><a class="dropdown-button" href="#!" data-activates="dropdown1">{{ Auth::user()->last_name }}<i class="material-icons right">arrow_drop_down</i></a></li>
                </ul>
            </div>
        </nav>
    </div>
@endif

{{---------------------------------------------------------------------------------}}