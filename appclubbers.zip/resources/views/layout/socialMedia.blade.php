<div class="row margin-top-social-media">
    <div class="col s12 l6 hide-on-med-and-down">
        {{--poner un reproductor de musica--}}
    </div>
    <div class="col s12 l6 offset-l6 right-align">
        <a href="#"><img class="responsive-img" style="width: 50px;" src="/assets/img/socialmediaFacebook.svg"></a>
        <a href="#"><img class="responsive-img" style="width: 50px;" src="/assets/img/socialmediaTwitter.svg"></a>
    </div>
</div>