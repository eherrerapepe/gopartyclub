<!doctype html>
<html lang="es">
<head>
    <title>@yield('title','AppClubbers')</title>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/materialize/0.97.5/css/materialize.min.css">
    <link rel="stylesheet" href="{{ asset('assets/css/main.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/animate.css') }}">
    <link href="http://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
    {{-- Cargamos los tipos de fuentes --}}
    <link href='https://fonts.googleapis.com/css?family=Courgette|Tangerine|Audiowide|Nova+Square|Mallanna|Mr+De+Haviland|Montez|Arizonia|Iceland|Mrs+Saint+Delafield|Miss+Fajardose' rel='stylesheet' type='text/css'>
</head>
<body>

    {{-- Check si el usuario esta logeado mostramos el nav del administrador --}}
    @if(Auth::check())
        @include('layout.navpanel')
    @endif

    @include('layout.nav')
    @include('layout.socialMedia')
    @include('layout.parallax')

    @yield('content')

    @include('layout.footer')

    <script src="{{ asset('assets/js/jquery.min.js') }}"></script>
    <script src="{{ asset('/assets/js/materialize.min.js') }}"></script>
    <script src="{{ asset('assets/js/main.js') }}"></script>
    <script src="{{ asset('assets/js/moment.js') }}"></script>
    <script src="{{ asset('assets/js/bootstrap-material-datetimepicker.js') }}"></script>
    <script src="{{ asset('assets/js/pinterest-query.js') }}"></script>

    {{-- Menu para subir y cambiar de idioma a la aplicacion --}}

    <div class="fixed-action-btn horizontal animated bounceInDown" style="bottom: 20px; right: 20px;">
        <a class="btn-floating btn-large pink">
            <i class="material-icons">language</i>
        </a>
        <ul>
            <li><a class="red" href="{{ url('lang', ['en']) }}" style="padding: 10px; -webkit-border-radius: 15px;-moz-border-radius: 15px;border-radius: 15px; color: white;">Englis</a></li>
            <li><a class="blue" href="{{ url('lang', ['es']) }}" style="padding: 10px; -webkit-border-radius: 15px;-moz-border-radius: 15px;border-radius: 15px; color: white;">Español</a></li>
        </ul>
    </div>

    {{--Google Api--}}
    <script type="text/javascript" src="http://maps.google.com/maps/api/js?libraries=places&sensor=false"></script>
    <script src="{{ asset('assets/js/googleMapsCl.js') }}"></script>
    <script src="{{ asset('assets/js/mapsRegisterEstablishments.js') }}"></script>
</body>
</html>