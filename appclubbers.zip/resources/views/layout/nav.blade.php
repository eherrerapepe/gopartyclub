<nav class="transparent z-depth-2 absolute">
    <div class="nav-wrapper">
        <a href="/" class="brand-logo"><h4 class="animated fadeIn title"><img style="width: 60px;" src="/assets/img/isotipo.svg"></h4></a>
        <a href="#" data-activates="mobile-demo-nav-main" class="button-collapse"><i class="material-icons">menu</i></a>
        <ul id="nav-mobile" class="right hide-on-med-and-down">
            <li><a class="black-text" href="{{ route('index') }}">{{ trans('custom.navUserHome') }}</a></li>
            <li><a class="black-text" href="{{ route('clubs') }}">{{ trans('custom.navUserClub') }}</a></li>
            <li><a class="black-text" href="{{ route('events') }}">{{ trans('custom.navUserEvent') }}</a></li>
            <li><a class="black-text" href="{{ route('profileDj') }}">{{ trans('custom.navUserDj') }}</a></li>
            <li><a class="black-text" href="{{ route('searchClubMap') }}">{{ trans('custom.navUserMap') }}</a></li>
            @if(!Auth::check())
                <li><a class="black-text" href="{{ route('login') }}">{{ trans('custom.navUserLogin') }}</a></li>
                <li><a class="black-text" href="{{ route('register') }}">{{ trans('custom.navUserRegister') }}</a></li>
            @endif
        </ul>
    </div>
    <ul class="side-nav" id="mobile-demo-nav-main">
        <li><a href="{{ route('index') }}">{{ trans('custom.navUserHome') }}</a></li>
        <li><a href="{{ route('clubs') }}">{{ trans('custom.navUserClub') }}</a></li>
        <li><a href="{{ route('events') }}">{{ trans('custom.navUserEvent') }}</a></li>
        <li><a href="{{ route('profileDj') }}">{{ trans('custom.navUserDj') }}</a></li>
        <li><a href="{{ route('searchClubMap') }}">{{ trans('custom.navUserMap') }}</a></li>
        @if(!Auth::check())
            <li><a href="{{ route('login') }}">{{ trans('custom.navUserLogin') }}</a></li>
            <li><a href="{{ route('register') }}">{{ trans('custom.navUserRegister') }}</a></li>
        @endif
    </ul>
</nav>
