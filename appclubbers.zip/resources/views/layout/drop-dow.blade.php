{{--  OPCIONES DE MENU PARA MODIFICAR EL PERFIL DE TODOS LOS USUARIOS REGISTRADOS --}}
<ul id="dropdown1" class="dropdown-content">
    <li><a href="{{ route('editPerfil') }}">Editar Perfil</a></li>
    <li class="divider"></li>
    <li><a href="{{ route('logout') }}">Salir</a></li>
</ul>
{{---------------------------------------------------------------------------------}}