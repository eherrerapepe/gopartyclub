<div class="parallax-container">
    <div class="parallax hide-on-large-only"><img src="/assets/img/logo1.svg"></div>
    <div class="parallax hide-on-med-and-down"><img src="/assets/img/logo.svg"></div>
</div>