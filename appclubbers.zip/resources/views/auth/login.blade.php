@extends('layout.master')

@section('content')
    <div class="container">
        <div class="row text-center">
            <h4 class="pink-text">{{ trans('custom.titleLogin') }}</h4>
            <hr>
        </div>
        <div class="row pink">
            <div class="col s12 m4 l4 white-text hide-on-small-only">
                <h1 class="text-center"><i class="material-icons large">person</i></h1>
                <p>{{ trans('custom.messageAccount') }} <a class="white-text" href="{{ route('register') }}">{{ trans('custom.messageRegister') }}</a></p>
                <p><a class="white-text" href="#!">{{ trans('custom.rememberPassword') }}</a></p>
                <p><a class="white-text" href="#!">{{ trans('custom.help') }}</a></p>
            </div>
            <div class="col s12 m8 white">
                <form method="POST" action="/auth/login">
                    {!! csrf_field() !!}

                    <div class="input-field s12">
                        <input type="email" name="email" value="{{ old('email') }}">
                        <label for="email">{{ trans('custom.email') }}</label>
                    </div>

                    <div class="input-field s12">
                        <input type="password" name="password" id="password">
                        <label for="password">{{ trans('custom.password') }}</label>
                    </div>

                    <div class="input-field s12">
                        <input type="checkbox" name="remember" id="remember" />
                        <label for="remember">{{ trans('custom.remember') }}</label>
                    </div>
                    <br>
                    <hr>
                    <div class="input-field s12 text-center">
                        <button class="btn waves waves-effect pink" type="submit">{{ trans('custom.btnLogin') }}</button>
                    </div>
                    <br><br>
                </form>
            </div>
            <div class="col s12 white-text hide-on-med-and-up">
                <h1 class="text-center"><i class="material-icons large">person</i></h1>
                <p>{{ trans('custom.messageAccount') }} <a class="white-text" href="{{ route('register') }}">{{ trans('custom.messageRegister') }}</a></p>
                <p><a class="white-text" href="#!">{{ trans('custom.rememberPassword') }}</a></p>
                <p><a class="white-text" href="#!">{{ trans('custom.help') }}</a></p>
            </div>
        </div>
    </div>
@endsection