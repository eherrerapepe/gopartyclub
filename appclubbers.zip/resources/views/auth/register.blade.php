@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col s12 offset-m1 m10">

                <div class="row text-center">
                    <h4>{{ trans('custom.titleRegister') }}</h4>
                    <div class="divider"></div>
                </div>

                <div class="row">
                    @if(count($errors)>0)
                        @include('messages.errors')
                    @endif
                </div>

                {!! Form::open( [ 'route' => 'register-post', 'method' => 'post']) !!}

                <input type="hidden" name="users[state]" value="1" >

                <div class="container">
                    <div class="col s12">
                        <ul class="tabs scroll-none">
                            <li class="tab tab1 col s3"><a class="active" href="#register1">{{ trans('custom.stepOne') }}</a></li>
                            <li class="tab tab2 col s3 disabled"><a href="#register2">{{ trans('custom.stepTwo') }}</a></li>
                            <li class="tab tab3 col s3 disabled"><a href="#register3">{{ trans('custom.stepThree') }}</a></li>
                        </ul>
                    </div>
                    <div id="register1" class="col s12">

                        <div class="row text-center">
                            <small>{{ trans('custom.messageRegisterStepOne') }}</small>
                        </div>

                        <div class="row">
                            <div class="row hidden">
                                <div id="map-canvas" class="z-depth-1-half"></div>
                                <input type="text" id="direccion" name="address[address]">
                                <input type="text" id="ciudad" name="address[city]">
                                <input type="text" id="pais" name="address[Country]">
                            </div>
                            <div class="row">
                                <div class="input-field col s12 m6">
                                    <input id="first_name" type="text" name="users[first_name]" class="validate" required>
                                    <label for="first_name">{{ trans('custom.registerFirstName') }} <small class="red-text">*</small></label>
                                </div>
                                <div class="input-field col s12 m6">
                                    <input id="last_name" type="text" name="users[last_name]" class="validate" required>
                                    <label for="last_name">{{ trans('custom.registerLastName') }} <small class="red-text">*</small></label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12">
                                    <input id="email" type="email" name="users[email]" class="validate">
                                    <label for="email">{{ trans('custom.email') }} <small class="red-text">*</small></label>
                                </div>
                            </div>
                            <div class="row">
                                <div class="input-field col s12 m6">
                                    <input id="password" type="password" name="password" class="validate" required>
                                    <label for="password">{{ trans('custom.password') }} <small class="red-text">*</small></label>
                                </div>
                                <div class="input-field col s12 m6">
                                    <input id="password" type="password" name="password_confirmation" class="validate" required>
                                    <label for="password">{{ trans('custom.passConfirmation') }} <small class="red-text">*</small></label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="divider"></div>
                            <div class="col offset-s6 s6 right-align">
                                <br>
                                <a class="btn waves waves-effect pink" onclick="$(document).ready(function(){$('.tab2').removeClass('disabled');$('ul.tabs').tabs('select_tab', 'register2');});" href="#!">{{ trans('custom.btnNext') }}</a>
                            </div>
                        </div>

                    </div>{{-- PASO 1 --}}
                    <div id="register2" class="col s12">
                        <div class="row text-center">
                            <small>{{ trans('custom.messageRegisterStepTwo') }} <a class="waves-effect waves-light modal-trigger red-text" href="#healpRegister">{{ trans('custom.clickMe') }}</a></small>
                            <div id="healpRegister" class="modal">
                                <div class="modal-content">
                                    <h4>En construccion</h4>
                                    <p>Aquí detallare la ayuda pertinente</p>
                                </div>
                                <div class="modal-footer">
                                    <a href="#!" class=" modal-action modal-close waves-effect waves-green btn-flat">Cerrar</a>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="col s4 center-align">
                                <div class="row">
                                    <img class="responsive-img circle" src="https://cdn2.iconfinder.com/data/icons/ios-7-icons/50/user_male2-128.png" alt="">
                                </div>
                                <div class="row">
                                    <input class="btn-radio" name="users[role]" value="Admin" type="radio" id="admin" checked/>
                                    <label for="admin">{{ trans('custom.typeUserAdmin') }}</label>
                                </div>
                            </div>
                            <div class="col s4 center-align">
                                <div class="row">
                                    <img class="responsive-img circle" src="https://cdn2.iconfinder.com/data/icons/ios-7-icons/50/user_male2-128.png" alt="">
                                </div>
                                <div class="row">
                                    <input name="users[role]" type="radio" value="Dj" id="dj" />
                                    <label for="dj">{{ trans('custom.typeUserDj') }}</label>
                                </div>
                            </div>
                            <div class="col s4 center-align">
                                <div class="row">
                                    <img class="responsive-img circle" src="https://cdn2.iconfinder.com/data/icons/ios-7-icons/50/user_male2-128.png" alt="">
                                </div>
                                <div class="row">
                                    <input name="users[role]" type="radio" value="Client" id="client" />
                                    <label for="client">{{ trans('custom.typeUserClient') }}</label>
                                </div>
                            </div>
                        </div>

                        <div class="row">
                            <div class="divider"></div>
                            <div class="col s6">
                                <br>
                                <a class="btn waves waves-effect pink accent-4" onclick="$(document).ready(function(){$('.tab2').addClass('disabled');$('ul.tabs').tabs('select_tab', 'register1');});" href="#!">{{ trans('custom.btnBack') }}</a>
                            </div>
                            <div class="col s6 right-align">
                                <br>
                                <a class="btn waves waves-effect pink" onclick="$(document).ready(function(){$('.tab3').removeClass('disabled');$('ul.tabs').tabs('select_tab', 'register3');});" href="#!">{{ trans('custom.btnNext') }}</a>
                            </div>
                        </div>
                    </div>{{-- PASO 2 --}}
                    <div id="register3" class="col s12">

                        <div class="row text-center">
                            <small>{{ trans('custom.messageRegisterStepThree') }}</small>
                        </div>

                        <div class="row">
                            <div class="input-field col s12 m6">
                                <input id="cell" type="text" name="contact[cell]" class="validate" required>
                                <label for="cell">{{ trans('custom.cell') }} <small class="red-text">*</small></label>
                            </div>
                            <div class="input-field col s12 m6">
                                <input id="number" type="text" name="contact[number]" class="validate">
                                <label for="number">{{ trans('custom.number') }}</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12">
                                <input id="web" type="text" name="contact[web]" class="validate">
                                <label for="web">{{ trans('custom.web') }}</label>
                            </div>
                        </div>
                        <div class="row">
                            <div class="input-field col s12 m6">
                                <input id="facebook" type="text" name="contact[facebook]" class="validate">
                                <label for="facebook">{{ trans('custom.pageFacebook') }}</label>
                            </div>
                            <div class="input-field col s12 m6">
                                <input id="twitter" type="text" name="contact[twitter]" class="validate">
                                <label for="twitter">{{ trans('custom.pageTwiter') }}</label>
                            </div>
                        </div>

                        <div class="row">
                            <div class="divider"></div>
                            <div class="col s6">
                                <br>
                                <a class="btn waves waves-effect pink accent-4" onclick="$(document).ready(function(){$('.tab3').addClass('disabled');$('ul.tabs').tabs('select_tab', 'register2');});" href="#!">{{ trans('custom.btnBack') }}</a>
                            </div>
                            <div class="col s6 right-align">
                                <br>
                                <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnRegisterNow') }}</button>
                            </div>
                        </div>
                    </div>{{-- PASO 3 --}}
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection