@extends('layout.master')

@section('content')
    <div class="container-fluid">

        <div class="row">
            <div class="col s12 m12 offset-l1 l10 background-base">
                <div class="row text-center">
                    <h4 class="animated bounceInLeft">{{ trans('custom.titleMap') }}</h4>
                    <div class="divider"></div>
                </div>

                <div class="row hidden">
                    <input type="hidden" value="{{ $lat }}" class="latitude_map">
                    <input type="hidden" value="{{ $lng }}" class="longitude_map">
                </div>

                <div class="row">
                    <div class="col s10 offset-s1 m12 animated bounceInUp">
                        <div id="mapClubbers">
                            {{-- Aki el mapa --}}
                        </div>
                    </div>
                </div>

            </div>
        </div>

    </div>
@endsection