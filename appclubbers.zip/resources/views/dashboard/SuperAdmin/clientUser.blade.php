@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @if(Session::has('message'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="btn close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    {{ Session::get('message') }}
                </div>
            @endif
        </div>

        <div class="row">
            <div class="col s12 m12 offset-l1 l10">
                <div class="row center-align">
                    <h3>Clientes Que Realizan Compras</h3>
                    <div class="divider"></div>
                </div>
                <div class="row">
                    <table class="responsive-table bordered striped highlight">
                        <thead>
                        <tr>
                            <th>Nombre</th>
                            <th>Email</th>
                            <th># Compras</th>
                            <th>Estado</th>
                            <th>Editar</th>
                        </tr>
                        </thead>
                        <tbody>
                        @foreach($userClients as $client)
                            <tr>
                                <td>{{ $client->first_name }} {{ $client->last_name }}</td>
                                <td>{{ $client->email }}</td>
                                <td>n/a</td>
                                <td {{ $client->state ? 'class=green-text' : 'class=red-text' }}>{{ $client->state ? 'Activo' : 'Inactivo' }}</td>
                                <td><a href="{{ route('stateUser',$client->id) }}">edit</a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>

        {{-- Pagination --}}
        <div class="row">
            <div class="text-center">
                {!! $userClients->render() !!}
            </div>
        </div>

    </div>
@endsection