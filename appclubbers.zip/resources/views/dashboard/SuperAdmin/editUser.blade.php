@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            <div class="col s12 m12 offset-l1 l10">
                <div class="row text-center">
                    <h5>Editando el Usuario {{ $user->first_name }} {{ $user->last_name }} de tipo {{ $user->role }}</h5>
                </div>
                <div class="row">
                    <div class="col s12 m12 offset-l2 l8">
                        {!! Form::open(['route'=> ['updateUser', $user->id],'method'=>'PUT']) !!}
                        <div class="input-field col s12">
                            <select name="role">
                                <option disabled selected>Seleccione el tipo de usuario</option>
                                <option value="Admin" {{ $user->role == 'Admin' ? 'selected' : '' }}>Admin</option>
                                <option value="Client" {{ $user->role == 'Client' ? 'selected' : '' }}>Cliente</option>
                                <option value="Dj" {{ $user->role == 'Dj' ? 'selected' : '' }}>Dj</option>
                            </select>
                            <label>Rol de Usuario</label>
                        </div>
                        <div class="input-field col s12">
                            <p>
                                <input value="1" name="state" type="radio" id="active-on" {{ $user->state == 1 ? 'checked' : '' }} />
                                <label for="active-on">Activado</label>
                            </p>
                            <p>
                                <input value="0" name="state" type="radio" id="active-off" {{ $user->state == 0 ? 'checked' : '' }} />
                                <label for="active-off">Suspendido</label>
                            </p>
                        </div>
                        <div class="row">
                            <br><br>
                            <div class="input-field col s12 text-center">
                                <button type="submit" class="btn waves waves-effect">Actualizar</button>
                            </div>
                        </div>
                        {!! Form::close() !!}
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection