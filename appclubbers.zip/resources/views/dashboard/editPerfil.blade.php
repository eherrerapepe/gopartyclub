@extends('layout.master')

@section('content')
    <div class="container-fluid">
        @include('messages.message')
        <div class="row">
            <div class="col s12 offset-l2 l8">
                <div class="col s12">
                    <ul class="tabs">
                        <li class="tab col s3"><a class="active" href="#perfil">{{ trans('custom.tabProfileIndex') }}</a></li>
                        <li class="tab col s3"><a href="#edit">{{ trans('custom.tabEditProfileIndex') }}</a></li>
                    </ul>
                </div>
                <div id="perfil" class="col s12">
                    <div class="row">
                        <h4>{{ trans('custom.titleProfile') }}</h4>
                        <div class="divider"></div>
                    </div>
                    <div class="row">
                        <div class="col s12 m9">
                            <div class="section">
                                <h5>{{ trans('custom.email') }}</h5>
                                <p>{{ $user->email }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                        <div class="col s12 m3 grey lighten-4">
                            <div class="section text-center">
                                @if($user->photo)
                                    <img class="responsive-img" src="/storage/{{ $user->photo }}">
                                    <p>{{ trans('custom.photoProfileAllUserTwo') }}</p>
                                @else
                                    <small class="red-text">{{ trans('custom.editProfileUploadPhoto') }}</small>
                                @endif
                            </div>
                        </div>
                    </div>
                    <div class="divider"></div>
                    <div class="row">
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>{{ trans('custom.registerFirstName') }}</h5>
                                <p>{{ $user->first_name }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>{{ trans('custom.registerLastName') }}</h5>
                                <p>{{ $user->last_name }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                    </div>
                    <div class="row">
                        <h4>{{ trans('custom.navUserContact') }}</h4>
                        <div class="divider"></div>
                    </div>
                    <div class="row">
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>{{ trans('custom.number') }}</h5>
                                <p>{{ $user->contactUser->number }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>{{ trans('custom.cell') }}</h5>
                                <p>{{ $user->contactUser->cell }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>Facebook</h5>
                                <p>{{ $user->contactUser->facebook }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                        <div class="col s12 m6">
                            <div class="section">
                                <h5>Twitter</h5>
                                <p>{{ $user->contactUser->twitter }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col s12">
                            <div class="section">
                                <h5>{{ trans('custom.web') }}</h5>
                                <p>{{ $user->contactUser->web }}</p>
                            </div>
                            <div class="divider"></div>
                        </div>
                    </div>
                    @if(($user->role <> 'Admin') && ($user->role <> 'SuperAdmin') )
                        <div class="row">
                            <h4>{{ trans('custom.addressTitleProfileDj') }}</h4>
                            <div class="divider"></div>
                        </div>
                        <div class="row">
                            <div class="col s12">
                                <div class="section">
                                    <h5>{{ trans('custom.addressProfileDj') }}</h5>
                                    <p>{{ $user->addressUserDj->address }}</p>
                                </div>
                                <div class="divider"></div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col s12 m6">
                                <div class="section">
                                    <h5>{{ trans('custom.addressProfileDjCity') }}</h5>
                                    <p>{{ $user->addressUserDj->city }}</p>
                                </div>
                                <div class="divider"></div>
                            </div>
                            <div class="col s12 m6">
                                <div class="section">
                                    <h5>{{ trans('custom.addressProfileDjCountry') }}</h5>
                                    <p>{{ $user->addressUserDj->Country }}</p>
                                </div>
                                <div class="divider"></div>
                            </div>
                        </div>
                    @endif
                </div>
                <div id="edit" class="col s12">
                    <div class="row">
                        @if(count($errors)>0)
                            @include('messages.errors')
                        @endif
                    </div>
                    {!! Form::open(['route'=> ['edit-update', $user->id],'method'=>'PUT','files' => true]) !!}
                    <div class="row">
                        <h4 class="text-center">{{ trans('custom.editProfileAllUser') }}</h4>
                        <hr>
                    </div>
                    <div class="row">
                        <div class="file-field input-field col s12 m6">
                            <div class="btn pink">
                                <span>{{ trans('custom.photoProfileAllUser') }}</span>
                                <input type="file" name="photo">
                            </div>
                            <div class="file-path-wrapper">
                                <input class="file-path validate" name="photo" type="text" placeholder="{{ trans('custom.placeholderPhotoAllUser') }}">
                            </div>
                        </div>
                        <div class="input-field col s12 m6">
                            <div class="row center-align">
                                <div class="col s6 offset-s3">
                                    @if($user->photo)
                                        <img class="responsive-img" src="/storage/{{ $user->photo }}">
                                        <p>{{ trans('custom.photoProfileAllUserTwo') }}</p>
                                    @else
                                        <p class="red-text">{{ trans('custom.photoNotSelect') }}</p>
                                    @endif
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input type="text" name="users[first_name]" class="validate" placeholder="Primer nombre..." value="{{ $user->first_name }}">
                            {!! Form::label('first_name',trans('custom.registerFirstName')) !!}
                        </div>
                        <div class="input-field col s12 m6">
                            <input type="text" name="users[last_name]" class="validate" placeholder="Apellidos Completos..." value="{{ $user->last_name }}">
                            {!! Form::label('last_name',trans('custom.registerLastName')) !!}
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <textarea name="users[description]" class="materialize-textarea" cols="30" rows="10" length="400">{{ $user->description }}</textarea>
                            {!! Form::label('descripcion', trans('custom.myProfile')) !!}
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input type="password" name="password" class="validate" placeholder="***********">
                            {!! Form::label('password',trans('custom.password')) !!}
                        </div>
                        <div class="input-field col s12 m6">
                            <input type="password" name="password_confirmation" class="validate" placeholder="***********">
                            {!! Form::label('passwordConfirmation',trans('custom.passConfirmation')) !!}
                        </div>
                    </div>
                    <div class="row text-center">
                        <h4>{{ trans('custom.navUserContact') }}</h4>
                        <div class="divider"></div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input type="text" name="users[email]" class="validate" placeholder="E-mail Actual: {{ $user->email }}...">
                            {!! Form::label('email',trans('custom.email')) !!}
                        </div>
                        <div class="input-field col s12 m6">
                            <input type="text" name="contact[number]" class="validate" placeholder="Número de Telefono Convencional (fijo)..." value="{{ $user->contactUser->number }}">
                            {!! Form::label('number',trans('custom.number')) !!}
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input type="text" name="contact[cell]" class="validate" placeholder="Número Personal de Celular..." value="{{ $user->contactUser->cell }}">
                            {!! Form::label('cell',trans('custom.cell')) !!}
                        </div>
                        <div class="input-field col s12 m6">
                            <input type="text" name="contact[web]" class="validate" placeholder="Sitio Web si lo Tuviese..." value="{{ $user->contactUser->web }}">
                            {!! Form::label('web',trans('custom.cell')) !!}
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12 m6">
                            <input type="text" name="contact[facebook]" class="validate" placeholder="Página web de facebook..." value="{{ $user->contactUser->facebook }}">
                            {!! Form::label('facebook',trans('custom.pageFacebook')) !!}
                        </div>
                        <div class="input-field col s12 m6">
                            <input type="text" name="contact[twitter]" class="validate" placeholder="Página web de twitter..." value="{{ $user->contactUser->twitter }}">
                            {!! Form::label('twitter',trans('custom.pageTwitter')) !!}
                        </div>
                    </div>

                    {{-- Le pasamos el id del usuario una para no hacerlo en el controlador --}}
                    <input type="hidden" name="contact[user_id]" value="{{ $user->id }}">

                    {{-- Opcion solo para dj --}}
                    @if(($user->role === 'Dj'))
                        {{-- Le pasamos el id del usuario una para no hacerlo en el controlador --}}
                        <input type="hidden" name="address[user_id]" value="{{ $user->id }}">
                        <div class="row">
                            <h4 class="text-center">{{ trans('custom.titleAddressDjProfileOptionEdit') }}</h4>
                            <hr>
                        </div>
                        <div class="row">
                            <small class="red-text">{{ trans('custom.descriptionProfileAddress') }}</small>
                        </div>
                        <div class="row">
                            <div class="input-field col s12 m4">
                                <input type="text" name="address[address]" class="validate" placeholder="Dirección" value="{{ $user->addressUserDj->address }}">
                                {!! Form::label('address',trans('custom.addressProfileDj')) !!}
                            </div>
                            <div class="input-field col s12 m4">
                                <input type="text" name="address[city]" class="validate" placeholder="Ciudad" value="{{ $user->addressUserDj->city }}">
                                {!! Form::label('city',trans('custom.addressProfileDjCity')) !!}
                            </div>
                            <div class="input-field col s12 m4">
                                <input type="text" name="address[Country]" class="validate" placeholder="País" value="{{ $user->addressUserDj->Country }}">
                                {!! Form::label('country',trans('custom.addressProfileDjCountry')) !!}
                            </div>
                        </div>
                    @endif


                    <div class="row">
                        <br><br>
                        <div class="input-field col s12 text-center">
                            <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSave') }}</button>
                        </div>
                    </div>
                    {!! Form::close() !!}
                </div>
            </div>
        </div>
    </div>
@endsection