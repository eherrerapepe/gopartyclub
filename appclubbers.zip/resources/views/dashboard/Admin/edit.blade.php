@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row text-center">
            <h1 class="pink-text">Editar Datos del Club</h1>
            <hr>
        </div>
        <div class="row">
            <div class="col s12 offset-l1 l10">
                {!! Form::model($establishment,['route'=> ['admin.establishment.update', $establishment->id],'method'=>'PUT','files' => true]) !!}
                    @include('forms.formEstablishment')

                    <div class="row">
                        <h4>Ubicación Geográfica del Club</h4>
                        <hr>
                    </div>
                    <div class="row">
                        <div class="col s12">
                            <div class="input-field col s12 m12 l6 offset-l3">
                                {!! Form::hidden('lat',null,['placeholder'=>'latitud','id'=>'lat']) !!}
                                {!! Form::hidden('lng',null,['placeholder'=>'longitud','id'=>'lng']) !!}

                                <input type="hidden" value="{{ $establishment->lat }}" id="Latitude">
                                <input type="hidden" value="{{ $establishment->lng }}" id="Longitude">

                                <input type="text" id="searchmap" placeholder="Escriba una direccion ejemplo: Mariano Castillo, Ambato, Tungurahua, Ecuador">
                                <label for="searchmap"><i class="material-icons">search</i>Buscar Dirección:</label>
                            </div>
                        </div>
                        <div class="col s12 m12 l10 offset-l1">
                            <div id="map-canvas" class="z-depth-1-half"></div>
                        </div>
                    </div>
                    <div class="row">
                        <div class="input-field col s12">
                            <input type="text" name="address" id="address" placeholder="Dirección">
                            {!! Form::label('address','Dirección del Establecimeinto') !!}
                        </div>
                    </div>

                    <div class="row">
                        <br><br>
                        <div class="input-field col s12 text-center">
                            <button type="submit" class="btn waves waves-effect pink">Guardar</button>
                        </div>
                    </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection