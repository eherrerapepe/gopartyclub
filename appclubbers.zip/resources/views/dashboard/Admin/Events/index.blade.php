@extends('layout.master')

@section('content')
    <div class="container-fluid">
        @include('messages.message')
        <div class="row">
            <div class="col s12 offset-l1 l10">
                <div class="row text-center">
                    <h4>{{ trans('custom.titleAddEvent') }}</h4>
                    <hr>
                    <a href="{{ route('admin.event.create') }}" class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
                    <p>{{ trans('custom.titleEventAdd') }}</p>
                </div>
                <div class="row">

                    @foreach($establishments as $establishment)

                        <div class="col s12 z-depth-1 cnt-event-index grey lighten-5">
                            <div class="row text-center">
                                <div class="col s12 m6 l4">
                                    <br>
                                    <img class="responsive-img" src="/storage/{{ $establishment->logo }}" alt="">
                                </div>
                                <div class="col s12 m6 l8">
                                    <h4 class="pink-text">{{ $establishment->name }}</h4>
                                    <hr>
                                    <p>{{ $establishment->description }}</p>
                                </div>
                            </div>
                            <div class="row">
                                @foreach($establishment->eventEstablishments as $event)

                                    <div class="col s12 m6 l4 grey lighten-4 z-depth-1-half">
                                        <div class="row text-center">
                                            <br>
                                            <img src="/storage/{{ $event->poster }}" class="responsive-img" style="height: 100px;">
                                        </div>
                                        <div class="row text-center">
                                            <p>{{ $event->name }}</p>
                                        </div>
                                        <div class="row text-center">
                                            <p><strong>{{ trans('custom.valueInto') }} </strong>{{ $event->price }}</p>
                                            <p><strong>{{ trans('custom.dateTime') }} </strong>{{ $event->date_in }}</p>
                                            <hr>
                                        </div>
                                        <div class="row text-center">
                                            <strong class="pink-text">{{ trans('custom.titleInvitation') }}</strong>
                                            <p>{{ substr($event->description, -100) }}</p>
                                        </div>
                                        <div class="row text-center">
                                            <a class="btn waves waves-effect pink accent-4" href="#"><i class="material-icons">delete_forever</i></a>
                                            <a class="btn waves waves-effect pink" href="{{ route('admin.event.edit',$event->id) }}"><i class="material-icons">edit</i></a>
                                            <a class="btn waves waves-effect orange modal-trigger" href="#detailEvent{{ $event->id }}"><i class="material-icons">details</i></a>
                                        </div>
                                    </div>

                                    {{-- space for modal windows --}}
                                    <div id="detailEvent{{ $event->id }}" class="modal modal-fixed-footer">
                                        <div class="modal-content">
                                            <div class="row">
                                                <h4>{{ $event->name }}</h4>
                                            </div>
                                            <div class="row">
                                                <p>{{ $event->description }}</p>
                                            </div>
                                            <div class="row">
                                                <div class="col s6">
                                                    <p><strong>{{ trans('custom.valueInto') }} </strong>{{ $event->price }}</p>
                                                </div>
                                                <div class="col s6">
                                                    <p><strong>{{ trans('custom.dateTime') }} </strong>{{ $event->date_in }}</p>
                                                </div>
                                            </div>
                                            <div class="row">
                                                <img src="/storage/{{ $event->poster }}" alt="" class="responsive-img">
                                            </div>
                                        </div>
                                        <div class="modal-footer">
                                            <a href="#!" class="modal-action modal-close waves-effect waves-green btn-flat pink-text">{{ trans('custom.btnClose') }}</a>
                                        </div>
                                    </div>

                                @endforeach
                            </div>
                        </div>

                    @endforeach

                </div>
            </div>
        </div>
    </div>
@endsection