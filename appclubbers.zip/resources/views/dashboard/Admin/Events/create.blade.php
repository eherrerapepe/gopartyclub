@extends('layout.master')

@section('content')
    <div class="row text-center">
        <div class="col s12 m12 l10 offset-l1">
            <h4>{{ trans('custom.titleCreateEvent') }}</h4>
            <hr>
        </div>
    </div>
    <div class="row">
        @if(count($errors)>0)
            @include('messages.errors')
        @endif
    </div>
    <div class="row">
        <div class="col s12 offset-l1 l10">
            {!! Form::open( [ 'route' => 'admin.event.store', 'method' => 'post', 'files' => true ] ) !!}
                @include('forms.formEvent')
                <div class="row">
                    <br><br>
                    <div class="input-field col s12 text-center">
                        <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSave') }}</button>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
@endsection