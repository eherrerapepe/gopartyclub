@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row text-center">
            <h4 class="pink-text">{{ trans('custom.titleEventFormAddEdit') }}</h4>
            <hr>
        </div>
        <div class="row">
            @if(Session::has('message'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="btn close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    {{ Session::get('message') }}
                </div>
            @endif
        </div>
        <div class="row">
            <div class="col s12 offset-l1 l10">
                {!! Form::model($event,['route'=> ['admin.event.update', $event->id],'method'=>'PUT','files' => true]) !!}
                @include('forms.formEditEvent')
                <div class="row">
                    <br><br>
                    <div class="input-field col s12 text-center">
                        <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSave') }}</button>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection