@extends('layout.master')

@section('content')
    <div class="row text-center">
        <h4>{{ trans('custom.titleAddNewEstablishment') }}</h4>
        <hr>
    </div>
    <div class="row">
        @if(count($errors)>0)
            @include('messages.errors')
        @endif
    </div>
    <div class="row">
        <div class="col s12 offset-l1 l10">
            {!! Form::open(['route'=> ['admin.establishment.store'],'files' => true]) !!}

                @include('forms.formEstablishment')

                <div class="row">
                    <h4>{{ trans('custom.titleAddMap') }}</h4>
                    <hr>
                </div>
                <div class="row">
                    <div class="col s12">
                        <div class="input-field col s12 m12 l6 offset-l3">
                            {!! Form::text('lat',null,['placeholder'=>'latitud','id'=>'lat','class'=>'hidden']) !!}
                            {!! Form::text('lng',null,['placeholder'=>'longitud','id'=>'lng','class'=>'hidden']) !!}

                            <input type="text" id="searchmap" placeholder="{{ trans('custom.sharedExampleMap') }}">
                            <label for="searchmap"><i class="material-icons">search</i>{{ trans('custom.titleSharedAddress') }}</label>
                        </div>
                    </div>
                    <div class="col s12 m12 l10 offset-l1">
                        <div id="map-canvas" class="z-depth-1-half"></div>
                    </div>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        <input type="text" name="address" id="address" placeholder="Dirección">
                        <label for="address">{{ trans('custom.titleLocationClub') }}</label>
                    </div>
                </div>

                <div class="row">
                    <h4>{{ trans('custom.titleAddServiceForm') }}</h4>
                    <hr>
                </div>
                <div class="row">
                    <div class="input-field col s12">
                        @foreach($services as $service)
                            <input type="checkbox" id="service{{ $service->id }}" name="option{{ $service->id }}" value="{{ $service->id }}" />
                            <label for="service{{ $service->id }}">{{ $service->name_service }}</label>
                        @endforeach
                    </div>
                </div>
                <div class="row">
                    <br><br>
                    <div class="input-field col s12 text-center">
                        <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSave') }}</button>
                    </div>
                </div>
            {!! Form::close() !!}
        </div>
    </div>
@endsection