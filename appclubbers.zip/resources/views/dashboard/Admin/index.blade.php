@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @if(Session::has('message'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="btn close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    {{ Session::get('message') }}
                </div>
            @endif
        </div>
        <div class="row">
            <div class="col s12 offset-l3 l6">
                <ul class="tabs">
                    <li class="tab col s3"><a class="active" href="#clubes">{{ trans('custom.tabNameClub') }}</a></li>
                    <li class="tab col s3"><a href="#services">{{ trans('custom.tabNameService') }}</a></li>
                </ul>
            </div>
            <div id="clubes" class="col s12 offset-l1 l10">
                <div class="row text-center">
                    <h4>{{ trans('custom.titleClubPrimary') }}</h4>
                    <hr>
                    <a href="{{ route('admin.establishment.create') }}" class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
                    <p class="red-text">{{ trans('custom.titleAddClub') }}</p>
                </div>
                <div class="row">
                    <table class="highlight centered responsive-table grey lighten-4">
                        <thead class="grey lighten-3">
                            <tr>
                                <th>{{ trans('custom.titleLogo') }}</th>
                                <th>{{ trans('custom.titleNameClub') }}</th>
                                <th>{{ trans('custom.titleType') }}</th>
                                <th>{{ trans('custom.titleCurrent') }}</th>
                                <th>{{ trans('custom.titleDelete') }}</th>
                                <th>{{ trans('custom.titleModify') }}</th>
                            </tr>
                        </thead>

                        <tbody>
                        @foreach($establishments as $item)
                            <tr>
                                <td width="130">
                                    <img class="responsive-img" src="/storage/{{ $item->logo }}" alt="{{ $item->name }}">
                                </td>
                                <td>{{ $item->name }}</td>
                                <td>{{ $item->type }}</td>
                                <td>{{ $item->currency }}</td>
                                <td><a class="btn waves waves-effect pink" href="#"><i class="material-icons">delete_forever</i></a></td>
                                <td><a class="btn waves waves-effect pink" href="{{ route('admin.establishment.edit',$item->id) }}"><i class="material-icons">edit</i></a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
            <div id="services" class="col s12">
                <div class="row">
                    <div class="col s12 offset-l1 l10">
                        <div class="row text-center">
                            <h4>{{ trans('custom.serviceClubes') }}</h4>
                            <hr>
                        </div>
                        @foreach($establishments as $establishment)
                            <div class="center-align hide-on-med-and-down">
                                <div class="col l2">
                                    <br>
                                    <strong>{{ trans('custom.titleNameClub') }}</strong>
                                    <hr>
                                </div>
                                <div class="col l6">
                                    <br>
                                    <strong>{{ trans('custom.titleServices') }}</strong>
                                    <hr>
                                </div>
                                <div class="col l4">
                                    <br>
                                    <strong>{{ trans('custom.titleAction') }}</strong>
                                    <hr>
                                </div>
                            </div>
                            <div class="row grey lighten-4">
                                <div class="col l2 s12">
                                    <div class="row">
                                        <br>
                                        <img class="responsive-img hide-on-med-and-down" src="/storage/{{ $establishment->logo }}">
                                    </div>
                                    <div class="row center-align">
                                        <p class="pink-text">{{ $establishment->name }}</p>
                                    </div>
                                </div>
                                <div class="col l6 s12">
                                    @foreach($establishment->serviceEstablishments as $service)
                                        <p>
                                            <input type="checkbox" name="{{ $service->id }}" id="{{ $service->name_service }}" checked disabled />
                                            <label for="{{ $service->name_service }}">{{ $service->name_service }}</label>
                                        </p>
                                    @endforeach
                                </div>
                                <div class="col l4 s12 center-align">
                                    <div class="hide-on-med-and-down"><br><br><br><br></div>
                                    <button class="btn waves waves-effect pink">x</button>
                                    <button class="btn waves waves-effect pink">e</button>
                                    <button class="btn waves waves-effect pink">+</button>
                                </div>
                            </div>
                        @endforeach
                    </div>
                </div>
            </div>
        </div>
    </div>
@endsection