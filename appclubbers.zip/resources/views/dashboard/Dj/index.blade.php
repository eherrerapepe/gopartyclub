@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row">
            @if(Session::has('message'))
                <div class="alert alert-success alert-dismissible" role="alert">
                    <button type="button" class="btn close" data-dismiss="alert" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                    {{ Session::get('message') }}
                </div>
            @endif
        </div>
        <div class="row">
            <div id="clubes" class="col s12 offset-l1 l10">
                <div class="row text-center">
                    <h4>{{ trans('custom.titleDjSong') }}</h4>
                    <hr>
                    <a href="{{ route('dj.djSong.create') }}" class="btn-floating btn-large waves-effect waves-light red"><i class="material-icons">add</i></a>
                    <h1 class="pink-text">{{ trans('custom.uploadSongDj') }}</h1>
                </div>
                <div class="row">
                    <table class="highlight centered responsive-table">
                        <thead>
                        <tr>
                            <th class="hide-on-med-and-down">{{ trans('custom.tableDisc') }}</th>
                            <th>{{ trans('custom.tableTitle') }}</th>
                            <th>{{ trans('custom.tableSong') }}</th>
                            <th>{{ trans('custom.tableDateIn') }}</th>
                            <th>{{ trans('custom.titleDelete') }}</th>
                            <th>{{ trans('custom.titleModify') }}</th>
                        </tr>
                        </thead>

                        <tbody>
                        @foreach( $djSongs as $song )
                            <tr>
                                <td width="130" class="hide-on-med-and-down">
                                    <img class="responsive-img" src="/storage/{{ $song->disco }}">
                                </td>
                                <td>{{ $song->title }}</td>
                                <td>
                                    <audio controls>
                                        <source src="/storage/{{ $song->song }}" type="audio/mpeg">
                                    </audio>
                                </td>
                                <td>{{ $song->date_time }}</td>
                                <td><a class="btn waves waves-effect pink" href="#"><i class="material-icons">delete_forever</i></a></td>
                                <td><a class="btn waves waves-effect pink" href="{{ route('dj.djSong.edit',$song->id) }}"><i class="material-icons">edit</i></a></td>
                            </tr>
                        @endforeach
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
@endsection