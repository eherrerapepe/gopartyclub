@extends('layout.master')

@section('content')
    <div class="row text-center">
        <h4>{{ trans('custom.formTitleUploadSong') }}</h4>
        <hr>
    </div>
    <div class="row">
        @if(count($errors)>0)
            @include('messages.errors')
        @endif
    </div>
    <div class="row">
        <div class="col s12 offset-l1 l10">
            {!! Form::open(['route'=> ['dj.djSong.store'],'files' => true]) !!}

            @include('forms.formDjSong')

            <div class="row">
                <br><br>
                <div class="input-field col s12 text-center">
                    <button type="submit" class="btn waves waves-effect pink">{{ trans('custom.btnSave') }}</button>
                </div>
            </div>
            {!! Form::close() !!}
        </div>
    </div>
@endsection