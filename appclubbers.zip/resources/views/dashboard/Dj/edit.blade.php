@extends('layout.master')

@section('content')
    <div class="container-fluid">
        <div class="row text-center">
            <h1 class="pink-text">Editar la Mezcla</h1>
            <hr>
        </div>
        <div class="row">
            <div class="col s12 offset-l1 l10">
                {!! Form::model($djSong,['route'=> ['dj.djSong.update', $djSong->id],'method'=>'PUT','files' => true]) !!}
                @include('forms.formDjSong')

                <div class="row">
                    <div class="col s12 m6">
                        <p>Images Actual: </p>
                        <div class="row">
                            <div class="col offset-m3 m6">
                                <img class="responsive-img" src="/storage/{{ $djSong->disco }}">
                            </div>
                        </div>
                    </div>
                    <div class="col s12 m6">
                        <p>Mezcla Actual: </p>
                        <br>
                        <audio controls>
                            <source src="/storage/{{ $djSong->song }}" type="audio/mpeg">
                        </audio>
                    </div>
                </div>

                <div class="row">
                    <br>
                    <div class="input-field col s12 text-center">
                        <button type="submit" class="btn waves waves-effect pink">Guardar</button>
                    </div>
                </div>
                {!! Form::close() !!}
            </div>
        </div>
    </div>
@endsection