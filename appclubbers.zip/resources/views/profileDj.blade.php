@extends('layout.master')

@section('content')
    <div class="container-fluid">

        <div class="row">
            <div class="col s12 m12 offset-l1 l10 background-base">

                <div class="row text-center">
                    <h4 class="animated bounceInLeft">{{ trans('custom.titleDj') }}</h4>
                    <hr>
                </div>
            </div>

            <div class="col s12 m12 offset-l1 l10">
                @foreach($djProfiles as $djProfile)
                    <div class="row grey lighten-4">
                    <div class="col s12 center-align">
                        <h4>{{ $djProfile->nick }}</h4>
                    </div>
                    <div class="col s12 m4 l3">
                        <img class="responsive-img hide-on-small-only" src="/storage/{{ $djProfile->photo }}">
                        <strong>{{ trans('custom.myProfile') }}</strong>
                        <p>{{ $djProfile->description }}</p>
                    </div>
                    <div class="col s12 m8 l4">
                        <p><strong>{{ trans('custom.email') }} </strong>{{ $djProfile->email }}</p>
                        <p><strong>WhatsApp: </strong>{{ $djProfile->contactUser->cell }}</p>
                        <p><strong>{{ trans('custom.number') }} </strong>{{ $djProfile->contactUser->number }}</p>
                        <p><strong>{{ trans('custom.web') }} </strong>{{ $djProfile->contactUser->web }}</p>
                        <p><strong>Facebook: </strong>{{ $djProfile->contactUser->facebook }}</p>
                        <p><strong>Twitter: </strong>{{ $djProfile->contactUser->twitter }}</p>
                    </div>
                    <div class="col s12 m12 l5">
                        <ul class="collection">
                            @foreach($djProfile->djSongs as $djSong)
                                <li class="collection-item avatar">
                                    <img src="/storage/{{ $djSong->disco }}"class="circle">
                                    <span class="title">{{ $djSong->title }}</span>
                                    <p>
                                        <audio controls><source src="/storage/{{ $djSong->song }}" type="audio/mpeg"></audio>
                                    </p>
                                    <a href="#!" class="secondary-content"><i class="material-icons">grade</i></a>
                                </li>
                            @endforeach
                        </ul>
                    </div>
                    <div class="col s12 center-align grey lighten-3">
                        <p><strong>{{ trans('custom.shared') }}</strong></p>
                        <button class="btn waves waves-effect blue darken-4">facebook</button>
                        <button class="btn waves waves-effect blue">twitter</button>
                        <br><br>
                    </div>
                </div>
                @endforeach
            </div>
        </div>
        {{-- Pagination --}}
        <div class="row">
            <div class="text-center">
                {!! $djProfiles->render() !!}
            </div>
        </div>

    </div>
@endsection