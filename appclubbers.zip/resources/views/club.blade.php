@extends('layout.master')

@section('content')
    <article class="container-fluid">

        <section class="row">
            <article class="col s12 m12 offset-l1 l10 background-base">

                <div class="row text-center">
                    <h4>{{ trans('custom.titleClub') }}</h4>
                    <hr>
                </div>

                <section id="club-loading">
                        @foreach($establishments as $est)
                        <article class="white-panel animated fadeInUpBig">
                            <div class="row">
                                <div class="col s12 z-depth-1">
                                    <div class="container-fluid">

                                        <div class="col s12 m6">

                                            <div class="card z-depth-0">
                                                <div class="card-image waves-effect waves-block waves-light">
                                                    <img class="activator responsive-img" src="/storage/{{ $est->logo }}">
                                                </div>
                                                <div class="card-content">
                                                    <span class="card-title activator grey-text text-darken-4">{{ trans('custom.titleClubPoint') }}</span>
                                                </div>
                                                <div class="card-reveal">
                                                    <span class="card-title grey-text text-darken-4">{{ $est->name }}<i class="material-icons right">close</i></span>
                                                    <small>{{ $est->description }}</small>
                                                </div>
                                            </div>

                                        </div>

                                        <div class="col s12 m6">

                                            <div class="row">
                                                <h4>{{ $est->name }}</h4>
                                                <p>{{ $est->type }}</p>
                                                <hr>
                                            </div>
                                            <div class="row">
                                                <p><i class="material-icons">room</i> <a href="{{ route('searchClubMap',$est->lat.'&'.$est->lng) }}">{{ trans('custom.linkMap') }}</a></p>
                                                <p><i class="material-icons">local_bar</i> <a href="{{ route('clubpoint',$est->id) }}">{{ trans('custom.linkEvent') }} </a>{{ count($est->eventEstablishments) }}</p>
                                            </div>

                                        </div>

                                    </div>
                                    <div class="row text-center">
                                        <hr>
                                        <a class="btn waves waves-effect pink accent-2" href="{{ route('clubpoint',$est->id) }}">{{ trans('custom.bntClubPoint') }}</a>
                                    </div>
                                </div>
                            </div>
                        </article>
                    @endforeach
                </section>

                {{-- Pagination --}}
                <div class="row">
                    <div class="text-center">
                         {!! $establishments->render() !!}
                    </div>
                </div>
            </article>
        </section>

    </article>
@endsection