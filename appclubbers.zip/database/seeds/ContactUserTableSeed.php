<?php

use Illuminate\Database\Seeder;

class ContactUserTableSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\ContactUser::class,50)->create();
    }
}
