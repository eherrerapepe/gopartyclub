<?php

use Illuminate\Database\Seeder;

class UsersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\User::class)->create([
            'first_name' => 'Edgar Armando',
            'last_name' => 'Herrera Pepe',
            'email' => 'eherrerapepe@gmail.com',
            'password' => \Hash::make('secret'),
            'role' => 'Dj',
            'state' => 1,
        ]);
        factory(App\User::class,50)->create();
    }
}
