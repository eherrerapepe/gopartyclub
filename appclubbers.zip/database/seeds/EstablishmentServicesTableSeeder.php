<?php

use Illuminate\Database\Seeder;

class EstablishmentServicesTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\EstablishmentService::class, 200)->create();
    }
}
