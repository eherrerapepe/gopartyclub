<?php

use Illuminate\Database\Seeder;

class EventsTableSeed extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        factory(App\Event::class, 500)->create();
    }
}
