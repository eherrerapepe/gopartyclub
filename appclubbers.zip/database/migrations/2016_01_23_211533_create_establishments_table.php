<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEstablishmentsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('establishments', function (Blueprint $table) {
            $table->increments('id');
            $table->text('logo');
            $table->string('name');
            $table->text('description');
            $table->double('lat');
            $table->double('lng');
            $table->string('address');
            $table->enum('type',['Bar','Discoteca','Karaoke']);
            $table->smallInteger('capacity');
            $table->boolean('state');
            $table->enum('currency',['USD','COP','MX']);
            $table->string('email')->nullable();
            $table->string('phono')->nullable();
            $table->string('cell')->nullable();
            $table->string('web')->nullable();
            $table->string('facebook')->nullable();
            $table->string('twitter')->nullable();
            $table->string('instagram')->nullable();
            $table->integer('user_id')->unsigned();
            $table->foreign('user_id')
                ->references('id')
                ->on('users');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('establishments');
    }
}
