<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateEstablishmentServicesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('establishment_services', function (Blueprint $table) {
            $table->increments('id');
            $table->integer('establishments_id')->unsigned();
            $table->foreign('establishments_id')
                ->references('id')
                ->on('establishments');
            $table->integer('services_id')->unsigned();
            $table->foreign('services_id')
                ->references('id')
                ->on('services');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::drop('establishment_services');
    }
}
