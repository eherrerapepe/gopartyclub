<?php

/*
|--------------------------------------------------------------------------
| Model Factories
|--------------------------------------------------------------------------
|
| Here you may define all of your model factories. Model factories give
| you a convenient way to create models for testing and seeding your
| database. Just tell the factory how a default model should look.
|
*/

$factory->define(App\User::class, function (Faker\Generator $faker) {
    return [
        'first_name' => $faker->firstName,
        'last_name' => $faker->lastName,
        'nick' => 'Dj '.$faker->userName,
        'email' => $faker->email,
        'password' => bcrypt('secret'),
        'role' => $faker->randomElement(['SuperAdmin','Admin','Client','Dj','Animator']),
        'state' => 1,
        'remember_token' => str_random(10),
    ];
});

$factory->define(App\ContactUser::class, function (Faker\Generator $faker) {
    return [
        'number' => $faker->phoneNumber,
        'cell' => '0993889292',
        'web' => 'www.loquesea.com',
        'facebook' => '/facebook/'.$faker->userName,
        'twitter' => '/twitter/'.$faker->userName,
        'user_id' => $faker->unique()->numberBetween($min = 1, $max = 50)
    ];
});

//$faker->unique()->numberBetween($min = 1, $max = 50)

$factory->define(App\Establishment::class, function (Faker\Generator $faker) {
    return [
        'lat' => $faker->randomElement(['-1.247220']),
        'lng' => $faker->randomElement(['-78.626967']),
        'logo' => $faker->randomElement(['1.jpg','2.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg']),
        'name' => $faker->citySuffix,
        'description' => $faker->text(200),
        'type' => $faker->randomElement(['Bar','Discoteca','Karaoke']),
        'capacity' => $faker->numberBetween(100,500),
        'state' => $faker->randomElement([1,0]),
        'currency' => $faker->randomElement(['USD','COP','MX']),
        'email' => $faker->email,
        'phono' => $faker->phoneNumber,
        'cell' => $faker->phoneNumber,
        'web' => $faker->domainName,
        'facebook' => 'https://www.facebook.com/'.$faker->userName,
        'twitter' => 'https://www.twitter.com/'.$faker->userName,
        'instagram' => 'https://www.instagram.com/'.$faker->userName,
        'user_id' => $faker->numberBetween($min = 1, $max = 51)
    ];
});

$factory->define(App\Event::class, function (Faker\Generator $faker) {
    return [
        'name' => 'Titulo del evento'.$faker->citySuffix,
        'description' => $faker->text(300),
        'poster' => $faker->randomElement(['1.jpg','2.jpg','4.jpg','5.jpg','6.jpg','7.jpg','8.jpg']),
        'date_in' => $faker->dateTime($max = 'now'),
        'price' => $faker->numberBetween($min = 1, $max = 15),
        'establishment_id' => $faker->numberBetween($min = 1, $max = 200),
    ];
});

$factory->define(App\Service::class, function (Faker\Generator $faker) {
    return [
        'name_service' => $faker->userName,
    ];
});

$factory->define(App\EstablishmentService::class, function (Faker\Generator $faker) {
    return [
        'establishments_id' => $faker->unique()->numberBetween(1,200),
        'services_id' => $faker->numberBetween(1,3)
    ];
});