$(document).ready(function(){
    $(".button-collapse").sideNav();
    $('.parallax').parallax();
    $('.slider').slider({full_width: true});
    $('select').material_select('destroy');
    $('select').material_select();
    $('ul.tabs').tabs();
    $('.modal-trigger').leanModal();
    $('.fixed-action-btn').openFAB();
    $('.fixed-action-btn').closeFAB();
    $('.tooltipped').tooltip({delay: 50});
    $('.tooltipped').tooltip('remove');

    $('#date-format').bootstrapMaterialDatePicker({ format : 'YYYY-MM-DD HH:mm', minDate : new Date() });

    $('#event-loading,#club-loading').pinterest_grid({
        no_columns: 3,
        padding_x: 10,
        padding_y: 10,
        margin_bottom: 30,
        single_column_breakpoint: 700
    });
});

/*Activar y ocultar*/
$(".test1").click(function () {
    $(".tab-conten > div").addClass('hidden');
    $('#test1').removeClass('hidden');
    $('li').removeClass('active');
    $(this).addClass('active');
});
$(".test2").click(function () {
    $(".tab-conten > div").addClass('hidden');
    $('#test2').removeClass('hidden');
    $('li').removeClass('active');
    $(this).addClass('active');
});
$(".test3").click(function () {
    $(".tab-conten > div").addClass('hidden');
    $('#test3').removeClass('hidden');
    $('li').removeClass('active');
    $(this).addClass('active');
});
$(".test4").click(function () {
    $(".tab-conten > div").addClass('hidden');
    $('#test4').removeClass('hidden');
    $('li').removeClass('active');
    $(this).addClass('active');
});
$(".test5").click(function () {
    $(".tab-conten > div").addClass('hidden');
    $('#test5').removeClass('hidden');
    $('li').removeClass('active');
    $(this).addClass('active');
});