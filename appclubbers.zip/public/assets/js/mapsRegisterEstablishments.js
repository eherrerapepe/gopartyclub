/**
 * Created by EdgarArmando on 22/2/2016.
 */
$(document).ready(function(){

    navigator.geolocation.getCurrentPosition( fn_ok, fn_error );

    //Funcion para cuando no nos autoriza a ontener la ubicacion
    function fn_error(){
        divMap.innerHTML = ' Error!. Para visualizar el mapa debe aceptar compartir su localización ';
    }

    //Funcion cunado si tenemos la autorizacion para obtener la ubicacion
    function fn_ok( response ) {
        //view_object(response.coords);
        //Guardamos la alatitud y la Longitud que obtenemos del response
        if($("#Latitude").val() != null && $("#Longitude").val() != null){
            var lat = parseFloat($("#Latitude").val());
            var lon = parseFloat($("#Longitude").val());
        }else{
            var lat = response.coords.latitude;
            var lon = response.coords.longitude;
        }

        $('#lat').val(lat);
        $('#lng').val(lon);

        var map = new google.maps.Map(document.getElementById('map-canvas'), {
            center: {
                lat: lat,
                lng: lon
            },
            zoom: 15
        });

        var marker = new google.maps.Marker({
            position: {
                lat: lat,
                lng: lon
            },
            map: map,
            draggable: true
        });

        var searchBox = new google.maps.places.SearchBox(document.getElementById('searchmap'));

        google.maps.event.addListener(searchBox, 'places_changed', function () {
            var places = searchBox.getPlaces();
            var bounds = new google.maps.LatLngBounds();
            var i, place;

            for (i = 0; place = places[i]; i++) {
                bounds.extend(place.geometry.location);
                marker.setPosition(place.geometry.location);
            }

            map.fitBounds(bounds);
            map.setZoom(15);
        });

        google.maps.event.addListener(marker, 'position_changed', function () {
            var lat = marker.getPosition().lat();
            var lng = marker.getPosition().lng();

            $('#lat').val(lat);
            $('#lng').val(lng);
        });

        function getAddress(){
            var latAddress = marker.getPosition().lat();
            var lngAddress = marker.getPosition().lng();

            var geocoder = new google.maps.Geocoder;
            var latlng = {
                lat: latAddress,
                lng: lngAddress
            };

            geocoder.geocode({'location': latlng}, function(results, status) {
                $('#address').val(results[1].formatted_address);

                //Opcion solo para dj
                var addressComplete = results[1].formatted_address;
                var direction = addressComplete.split(',');

                $('#direccion').val(direction[direction.length-3]);
                $('#ciudad').val(direction[direction.length-2]);
                $('#pais').val(direction[direction.length-1]);

            });
        }
        $('#map-canvas').mouseup(function(event){
            getAddress();
        });
        $('#searchmap').mouseup(function(event){
            getAddress();
        });

        getAddress();

    }

});