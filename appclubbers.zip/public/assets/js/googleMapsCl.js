/**
 * Created by EdgarArmando on 2/2/2016.
 */
$(document).ready(function(){

    //NAMESPACE ---> google.maps.ALGO

    //Obtenemos el id del div que contendra el mapa
    var divMap = document.getElementById('mapClubbers');

    //Funcion callback
    navigator.geolocation.getCurrentPosition( fn_ok, fn_error );

    //Funcion para cuando no nos autoriza a ontener la ubicacion
    function fn_error(){
        divMap.innerHTML = ' Error!. Para visualizar el mapa debe aceptar compartir su localización ';
    }

    //Funcion cunado si tenemos la autorizacion para obtener la ubicacion
    function fn_ok( response ){
        //view_object(response.coords);
        //Guardamos la alatitud y la Longitud que obtenemos del response
        if($('.latitude_map').val() != 0 && $('.longitude_map').val() != 0){
            var lat = parseFloat($('.latitude_map').val());
            var lon = parseFloat($('.longitude_map').val());
        }else{
            var lat = response.coords.latitude;
            var lon = response.coords.longitude;
        }

        //Convertir esos datos en un objeto para que pueda leer la api de google
        var gLatLon = new google.maps.LatLng( lat, lon );

        //Parametro de configuracion para el canvas del nuestro Map (Variable de tipo object)
        var objectConfiguration = {
            zoom: 17,
            center: gLatLon,
            rotateControl:true
        };

        var lat = response.coords.latitude;
        var lon = response.coords.longitude;
        var gLatLonUser = new google.maps.LatLng( lat, lon );

        //Este es el mapa interactivo es decir el canvas; este recibe dos parametro el primero el div donde se va a dibujar y el objeto de configuracion como segundo parametro
        var gMap = new google.maps.Map( divMap, objectConfiguration );

        //Configuramos el objeto que minimo acepta la posicion (Lat,Long) y en que mapa se va a mostrar
        var objectConfigurationMarker = {
            map: gMap,
            position: gLatLonUser,
            draggable: true,
            //animation: google.maps.Animation.BOUNCE,
            title: 'Usted esta ubicado aki'
        };

        //Agregando las Marker
        var gMarker = new google.maps.Marker( objectConfigurationMarker );

        //Escribimos un mensaje sobre el Maker del Usuario para decirle que esta ubicado aqui
        var infowindow = new google.maps.InfoWindow({
            content:"Clubber's! Esta es tu ubicación"
        });

        //Markers de la base de datos leemos el archivo json y convertimos en array de datos
        $.getJSON("/dates/markerClubbers.json", function(dates) {

            //console.log(dates);

            var markerClubs = [];
            for (var id in dates) {
                markerClubs.push(dates[id]);
            }
            //console.log(markerClubs[3]);

            //Marker info de los puntos consultados en la base de datos
            var infoWindowsClubes = new google.maps.InfoWindow();
            var markerClub, i;
            for(i = 0; i < markerClubs.length; i++){
                markerClub = new google.maps.Marker({
                    position: new google.maps.LatLng( markerClubs[i]['Lat'], markerClubs[i]['Lng'] ),
                    map: gMap
            });
                google.maps.event.addListener(markerClub, 'click', (function(markerClub, i){
                    return function(){
                        infoWindowsClubes.setContent(markerClubs[i]['Title']);
                        infoWindowsClubes.open(gMap, markerClub);
                    }
                })( markerClub, i ));

        }

        });



        /*
        infowindow.open(gMap,gMarker);

        //Traducimos una direccion a coordenadas para luego ser mostradas en el nuevo marker
        var gCoder = new google.maps.Geocoder();
        //Objeto que necesita basicamente un address
        var objectInformation = {
            address: 'Cafetería Créme Brûlée, Ambato, Tungurahua, Ecuador'
        };
        //Traducimos la direccion mediante el objeto gCoder
            gCoder.geocode(objectInformation, fn_coder);
        //La funcion fn_coder se lanza cuando todo sale bien
        function fn_coder( dates ){
            var coordinates = dates[0].geometry.location; //Este es el objeto latitud y longitud

            //Configuramos la nueva Chinche Marker que se va a mostrar
            var config = {
                map: gMap,
                position: coordinates,
                title: 'Cafeteria'
            };

            //Creamos una nueva Marker
            var gMarkerNew = new google.maps.Marker( config );

            //Personalizamos los marker para que muestre informacion al hacerle clikc sobre el marker
            var infoWindowClubes = new google.maps.InfoWindow({
                content:"Aki tendria que mostrar una informacion mas grande <a href='appclubbers.com' >clubbers Site</a>"
            });

            google.maps.event.addListener(gMarkerNew, 'click', function() {
                infoWindowClubes.open(gMap,gMarkerNew);
            });

        }

        */


    }

    //Funcion solo para el desarrollo para mostrar los datos de los objetos
    function view_object( obj ){
        for(var prop in obj){
            document.write(prop + ':' + obj[prop] + '</br>');
        }
    }

});