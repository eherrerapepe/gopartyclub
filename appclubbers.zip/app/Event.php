<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Event extends Model
{
    protected $table = 'events';

    protected $fillable = ['poster','name','description','date_in','establishment_id','price','date_in'];
}
