<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Establishment extends Model
{
    protected $table = 'establishments';
    protected $fillable = ['logo','name','lat','lng','description','type','address','capacity','state','currency','email','phono','cell','web','facebook','twitter','instagram','user_id'];

    //Consultamos todos los servicios que pertenecen al establesimiento
    public function serviceEstablishments(){
        return $this->belongsToMany('App\Service','establishment_services','establishments_id','services_id');
    }

    //Consultamos los eventos que pertenecen a cada establecimiento
    public function eventEstablishments(){
        return $this->hasMany('App\Event','establishment_id');
    }
}
