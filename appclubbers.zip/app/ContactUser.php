<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ContactUser extends Model
{
    protected $table = 'contact_users';
    protected $fillable = ['number','cell','web','facebook','twitter','user_id'];
}
