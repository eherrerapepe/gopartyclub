<?php

/*
 * Rutas para registrar y logear a los usuarios
 */

Route::group(['middleware'=>['web']], function(){

    //Leguage change
    Route::get('lang/{lang}', function ($lang) {
        session(['lang' => $lang]);
        return \Redirect::back();
    })->where([
        'lang' => 'en|es'
    ]);

    //Inyection of dependences


    // AUTHENTICATION ------------------
    Route::get('auth/login', [
        'as' => 'login',
        'uses' => 'Auth\AuthController@getLogin'
    ]);
    Route::post('auth/login', [
        'as' => 'login-post',
        'uses' => 'Auth\AuthController@postLogin'
    ]);
    Route::get('auth/logout', [
        'as' => 'logout',
        'uses' => 'Auth\AuthController@getLogout'
    ]);

    // REGISTER USER...
    Route::get('auth/register', [
        'as' => 'register',
        'uses' => 'Auth\AuthController@getRegister'
    ]);
    Route::post('auth/register', [
        'as' => 'register-post',
        'uses' => 'Auth\AuthController@postRegister'
    ]);

    // SUPER-ADMIN -------------

    Route::group(['namespace' => 'SuperAdmin', 'middleware' => ['auth','is_SuperAdmin'], 'prefix' => 'superAdmin'], function()
    {
        Route::get('/panelSuperAdmin',['as' => 'homeSuperAdmin', 'uses' => 'SuperAdminController@home' ]);
        Route::get('/Admin',['as' => 'adminUser', 'uses' => 'SuperAdminController@adminUser' ]);
        Route::get('/Client',['as' => 'clientUser', 'uses' => 'SuperAdminController@clientUser' ]);
        Route::get('/Dj',['as' => 'djUser', 'uses' => 'SuperAdminController@djUser' ]);

        //Opcion de edicion del estado del usuario esta opcion es general para todos los usuarios
        Route::get('edit-user/{id}', ['as' => 'stateUser','uses' => 'SuperAdminController@edit']);
        Route::put('update-user/{id}', ['as' => 'updateUser','uses' => 'SuperAdminController@update']);
    });

    // ADMIN -------------

    Route::group(['namespace' => 'Admin', 'middleware' => ['auth','is_admin'], 'prefix' => 'admin'], function()
    {
        Route::get('/panelAdmin',['as' => 'homeAdmin', 'uses' => 'EstablishmentController@homeAdmin' ]);
        Route::resource('establishment', 'EstablishmentController');
        Route::resource('event','EventController');
        Route::resource('service','ServiceController');

    });


    // DJ -------------

    Route::group(['namespace' => 'Dj', 'middleware' => ['auth','is_Dj'], 'prefix' => 'dj'], function()
    {
        Route::get('/panelDj',['as' => 'homeDj', 'uses' => 'DjController@homeDj' ]);
        Route::resource('djSong','DjSongController');

    });

    // CLIENT -------------

    Route::group(['namespace' => 'Client', 'middleware' => ['auth','is_Client'], 'prefix' => 'client'], function()
    {
        Route::get('/panelClient',['as' => 'homeClient', 'uses' => 'ClientController@homeClient' ]);
        Route::get('/shopping',['as' => 'shopping', 'uses' => 'ClientController@shoppingClient' ]);

    });

    // EDICION DE PERFIL DE USUARIOS ---------------------
    Route::group(['middleware'=>'auth'], function(){
        Route::get('edit-perfil',[
            'as' => 'editPerfil',
            'uses' => 'UserProfileController@edit'
        ]);

        Route::put('edit-update/{id}', [
            'as' => 'edit-update',
            'uses' => 'UserProfileController@update'
        ]);
    });

    // ROUTER PARA INDEX ---------------------------
    Route::resource('mail','MailController');
    Route::get('/',['as'=>'index','uses'=>'IndexController@index']);
    Route::get('/clubs',['as'=>'clubs','uses'=>'IndexController@club']);
    Route::get('/clubs/{id}',['as'=>'clubpoint','uses'=>'IndexController@clubPoint']);
    Route::get('/eventos',['as'=>'events','uses'=>'IndexController@events']);
    Route::get('/dj',['as'=>'profileDj','uses'=>'IndexController@dj']);
    Route::get('/appClubersInMapGoogle/{location?}',['as'=>'searchClubMap','uses'=>'SearchClubesInMap\SearchClubMapController@index']);

    //CARRITO -------------------------
    Route::get('cart/show',[
        'as' => 'cart-show',
        'uses' => 'CartController@show'
    ]);

});
