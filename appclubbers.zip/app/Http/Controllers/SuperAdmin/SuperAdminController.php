<?php

namespace App\Http\Controllers\SuperAdmin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Establishment;
use App\User;

class SuperAdminController extends Controller
{
    public function home(){
        return view('dashboard.SuperAdmin.home');
    }

    public function adminUser(){

        $clubes = Establishment::join('users','establishments.user_id','=','users.id')
            ->where('users.role','Admin')
            ->select('establishments.id as idClub','establishments.currency','establishments.name','establishments.state as stateClub','users.id as idUser','users.first_name','users.last_name','users.email','users.photo','users.state as stateUser')
            ->orderBy('establishments.currency','asc')
            ->paginate();

        //dd($clubes);

        return view('dashboard.SuperAdmin.adminUser', compact('clubes'));
    }

    public function clientUser(){
        $userClients = User::where('users.role','Client')->paginate();
        return view('dashboard.SuperAdmin.clientUser', compact('userClients'));
    }

    public function djUser(){
        $userDj = User::where('users.role','Dj')->paginate();
        return view('dashboard.SuperAdmin.djUser', compact('userDj'));
    }

    //Editamos el usuario pasandole el id valido para all users
    public function edit($id){
        $user = User::find($id);
        //dd($user);
        return view('dashboard.SuperAdmin.editUser',['user'=>$user]);
    }

    public function update(Request $requests, $id){
        $data = User::find($id);
        $data['role'] = $requests->get('role');
        $data['state'] = $requests->get('state');

        $data->save();

        return view('dashboard.SuperAdmin.home');
    }
}
