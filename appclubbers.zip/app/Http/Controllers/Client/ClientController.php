<?php

namespace App\Http\Controllers\Client;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class ClientController extends Controller
{
    public function homeClient()
    {
        return view('dashboard.Client.home');
    }

    public function shoppingClient()
    {
        return view('dashboard.Client.shopping');
    }
}
