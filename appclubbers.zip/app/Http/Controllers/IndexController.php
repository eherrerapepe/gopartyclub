<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Establishment;
use App\User;
use App\Event;
use App\ContactUser;
use App\DjSong;
use Auth;

class IndexController extends Controller
{
    public function index()
    {
        return view('index');
    }

    public function club(){
        $establishments = Establishment::with('serviceEstablishments','eventEstablishments')->paginate();
        //dd($establishments);
        return view('club', compact('establishments'));
    }

    public function clubPoint($id){

        $club = Establishment::with('serviceEstablishments','eventEstablishments')->where('establishments.id',$id)->first();

        $flagEvent = count($club->eventEstablishments);

        $user = User::with('contactUser')->find($club->user_id);

        //dd($club);

        return view('clubPoint',['club'=>$club,'user'=>$user,'flagEvent'=>$flagEvent]);
    }

    public function events(){
        //$hoy = date("Y-m-d H:i:s");
        $events = Event::select('events.name as name_event','events.description as event_description','events.*','establishments.*')
            ->join('establishments','events.establishment_id','=','establishments.id')
            //->where('events.date_in', '>=', $hoy)
            ->orderBy('events.date_in','asc')
            ->paginate();
        //dd($events);
        return view('event',compact('events'));
    }

    public function dj(){

        $djProfiles = User::with('contactUser','djSongs')
        ->where('users.role','DJ')
        ->paginate(7);

        //dd($djProfiles);

        return view('profileDj',['djProfiles'=>$djProfiles]);
    }

}
