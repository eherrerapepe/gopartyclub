<?php

namespace App\Http\Controllers\Dj;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\DjSongRequest;
use App\Http\Controllers\Controller;
use Session;
use Auth;
use App\DjSong;

class DjSongController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $idUser = Auth::user()->id;

        //Consultamos todas las musicas que le pertenescan al user logeado
        $djSongs = DjSong::where('user_id',$idUser)->get();

        //dd($djSongs);

        return view('dashboard.Dj.index',compact('djSongs'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('dashboard.Dj.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(DjSongRequest $request)
    {
        $dataDjSong = $request->all();

        $fileDisco = \Input::file('disco');
        $nameDisco = date('Y-m-d').rand(0,290).rand(4,892).$fileDisco->getClientOriginalName();
        $extensionFile = $fileDisco->getClientOriginalExtension();
        \Storage::disk('local')->put($nameDisco,  \File::get($fileDisco));
        $dataDjSong['disco'] = $nameDisco;

        $fileSong = \Input::file('song');
        $nameSong = date('Y-m-d').rand(0,290).rand(4,892).$fileSong->getClientOriginalName();
        $extensionFile = $fileSong->getClientOriginalExtension();
        \Storage::disk('local')->put($nameSong,  \File::get($fileSong));
        $dataDjSong['song'] = $nameSong;

        $registerDjSong = DjSong::create($dataDjSong);

        //dd($dataDjSong);

        $registerDjSong ? Session::flash('message','Mezcla subida correctamente') : Session::flash('message','Ups.! Algo salio mal...');

        return redirect()->route('dj.djSong.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $djSong = DjSong::find($id);
        //dd($djSong);
        return view('dashboard.Dj.edit', ['djSong'=>$djSong]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(DjSongRequest $request, $id)
    {
        $djSong = DjSong::find($id);

        $dataDjSong = $request->all();

        if( $request->disco != null && $request->song != null ){
            $fileDisco = \Input::file('disco');
            $nameDisco = date('Y-m-d').rand(0,290).rand(4,892).$fileDisco->getClientOriginalName();
            $extensionFile = $fileDisco->getClientOriginalExtension();
            \Storage::disk('local')->put($nameDisco,  \File::get($fileDisco));
            $dataDjSong['disco'] = $nameDisco;

            $fileSong = \Input::file('song');
            $nameSong = date('Y-m-d').rand(0,290).rand(4,892).$fileSong->getClientOriginalName();
            $extensionFile = $fileSong->getClientOriginalExtension();
            \Storage::disk('local')->put($nameSong,  \File::get($fileSong));
            $dataDjSong['song'] = $nameSong;

        }elseif( $request->disco != null ){
            $fileDisco = \Input::file('disco');
            $nameDisco = date('Y-m-d').rand(0,290).rand(4,892).$fileDisco->getClientOriginalName();
            $extensionFile = $fileDisco->getClientOriginalExtension();
            \Storage::disk('local')->put($nameDisco,  \File::get($fileDisco));
            $dataDjSong['disco'] = $nameDisco;
            $dataDjSong['song'] = $djSong->song;
        }elseif( $request->song != null ){
            $fileSong = \Input::file('song');
            $nameSong = date('Y-m-d').rand(0,290).rand(4,892).$fileSong->getClientOriginalName();
            $extensionFile = $fileSong->getClientOriginalExtension();
            \Storage::disk('local')->put($nameSong,  \File::get($fileSong));
            $dataDjSong['song'] = $nameSong;
            $dataDjSong['disco'] = $djSong->disco;

        }else{
            $dataDjSong['disco'] = $djSong->disco;
            $dataDjSong['song'] = $djSong->song;
        }

        //dd($dataDjSong);

        $djSong->fill($dataDjSong);

        $djSong->save();

        $djSong ? Session::flash('message','Sonido Actualizado') : Session::flash('message','Algo salio re-mal');

        return redirect()->route('dj.djSong.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
