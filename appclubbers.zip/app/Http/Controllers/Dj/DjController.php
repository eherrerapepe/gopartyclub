<?php

namespace App\Http\Controllers\Dj;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class DjController extends Controller
{
    public function homeDj(){
        return view('dashboard.Dj.home');
    }
}
