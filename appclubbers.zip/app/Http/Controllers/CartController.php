<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;

class CartController extends Controller
{
   //Creamos la variable de sesion si no existe
    public function __construct()
    {
        if(!\Session::has('cart')) \Session::put('cart',array());
    }

    //Show cart
    public function show()
    {
        return \Session::get('cart');
    }
}
