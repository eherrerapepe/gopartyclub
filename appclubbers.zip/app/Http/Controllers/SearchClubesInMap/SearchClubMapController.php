<?php

namespace App\Http\Controllers\SearchClubesInMap;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Controllers\Controller;
use App\Establishment;

class SearchClubMapController extends Controller
{
    public function index($location = '0&0') {

        //Consultamos todos los establecimientos incluyendo la Latitud y la Longitud
        $establishments = Establishment::select('id','logo','name','type','description','lat','lng')->get();
        //dd($establishments->toArray());
        $i= 0;
        foreach($establishments as $establishment){
            $establishmentArray[$i] =
                $club = array(
                    'Title' =>
                        "<div class='row'>".
                        "<div class='col s4'><a href='/clubs/$establishment->id'><img class='responsive-img' src='/storage/$establishment->logo'/></a></div>"
                        ."<div class='col s8'>"."<h1>"
                        .$establishment->name.
                        " <small>"
                        .$establishment->type.
                        "</small></h1>"."</div>"
                        ."</div>"
                        ."<p>"
                        .$establishment->description.
                        "</p>"
                        ."<a href='/clubs/$establishment->id'>Visitar Sitio</a>",

                    'Lat' => $establishment->lat,
                    'Lng' => $establishment->lng
                );
            $i++;
        }

        //dd($establishmentArray);


        $jsonClubbers = json_encode($establishmentArray,JSON_UNESCAPED_UNICODE);

        //dd($jsonClubbers);

        $fh = fopen("dates/markerClubbers.json", 'w');
        fwrite($fh, $jsonClubbers);
        fclose($fh);

        //Tomamos la location y la dividimos para pasar a la vista
        $locations = explode('&',$location);
        $lat = $locations[0];
        $lng = $locations[1];

        return view('clubesInMap',compact('lat','lng'));
    }
}
