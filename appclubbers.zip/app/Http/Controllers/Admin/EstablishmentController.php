<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\EstablishmentRequest;
use App\Http\Controllers\Controller;
use App\Establishment;
use App\Service;
use App\EstablishmentService;
use Session;
use Auth;

class EstablishmentController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $establishments = Establishment::with('serviceEstablishments')
            ->where('establishments.user_id',Auth::user()->id)->get();
        //dd($establishments);
        return view('dashboard.Admin.index', ['establishments'=>$establishments]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $services = Service::all();
        return view('dashboard.Admin.create',['services'=>$services]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EstablishmentRequest $request)
    {
        //obtenemos el campo file definido en el formulario
        $file = $request->file('logo');
        //obtenemos el nombre del archivo
        $nombre = date('Y-m-d').rand(0,290).rand(4,892).$file->getClientOriginalName();
        //indicamos que queremos guardar un nuevo archivo en el disco local
        \Storage::disk('local')->put($nombre,  \File::get($file));


        $data = [
            'logo' => $nombre,
            'name' => $request->get('name'),
            'description' => $request->get('description'),
            'lat' => $request->get('lat'),
            'lng' => $request->get('lng'),
            'address' => $request->get('address'),
            'type' => $request->get('type'),
            'capacity' => $request->get('capacity'),
            'state' => 1,
            'email' => $request->get('email'),
            'phono' => $request->get('phono'),
            'cell' => $request->get('cell'),
            'web' => $request->get('web'),
            'facebook' => $request->get('facebook'),
            'twitter' => $request->get('twitter'),
            'instagram' => $request->get('instagram'),
            'user_id' => Auth::user()->id,
        ];

        $establishment = Establishment::create($data);

        $idEstablishment = $establishment->id; //obtenemos el id del establecimiento recien registrado

        for($i=1; $i<=3; $i++)
        {
            if($request->get('option'.$i)){
                EstablishmentService::create([
                    'establishments_id' => $idEstablishment,
                    'services_id' => $request->get('option'.$i)
                ]);
            }
        }

        $establishment ? Session::flash('message','Establesimiento Correctamente Registrado') : Session::flash('message','Establesimiento no Registrado algo salio mal');

        return redirect()->route('admin.establishment.index');

    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        return Establishment::find($id);
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $establishment = Establishment::find($id);
        //dd($establishment);
        return view('dashboard.Admin.edit', ['establishment'=>$establishment]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update($id, EstablishmentRequest $request)
    {
        $establishment = Establishment::find($id);

        $dataEstablishment = $request->all();

        if(empty($request->logo)){
            $logo = $establishment->logo;
            $dataEstablishment['logo'] = $logo;
        }else{
            //obtenemos el campo file definido en el formulario
            $file = $request->file('logo');
            //obtenemos el nombre del archivo
            $nombre = date('Y-m-d').rand(0,290).rand(4,892).$file->getClientOriginalName();
            //indicamos que queremos guardar un nuevo archivo en el disco local
            \Storage::disk('local')->put($nombre,  \File::get($file));
            $dataEstablishment['logo'] = $nombre;
        }

        $establishment->fill($dataEstablishment);

        $establishment->save();

        Session::flash('message','Establesimiento Correctamente Actualizado');

        return redirect()->route('admin.establishment.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }


    //Retornamos la vista de panel admin
    public function homeAdmin(){
        return view('dashboard.Admin.home');
    }
}
