<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\EventRequest;
use App\Http\Controllers\Controller;
use App\Establishment;
use App\Event;
use Auth;
use Session;

class EventController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $events = Establishment::with('eventEstablishments')
            ->where('establishments.user_id',Auth::user()->id)
            ->get();
        //dd($events);
        return view('dashboard.Admin.Events.index',['establishments'=>$events]);
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $establishments = Establishment::select('id','name','logo')
            ->where('establishments.user_id',Auth::user()->id)
            ->get();
        //dd($establishments);
        return view('dashboard.Admin.Events.create', ['establishments'=>$establishments]);
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(EventRequest $request)
    {
        //obtenemos el campo file definido en el formulario
        $file = $request->file('poster');
        //dd($request);
        //obtenemos el nombre del archivo
        $nombre = date('Y-m-d').rand(0,290).rand(4,892).$file->getClientOriginalName();
        //indicamos que queremos guardar un nuevo archivo en el disco local
        \Storage::disk('local')->put($nombre,  \File::get($file));

        $dataEvent = $request->get('event');
        $dataEvent['poster'] = $nombre;
        //dd($dataEvent);
        $create = Event::create($dataEvent);

        $create ? Session::flash('message','Evento Correctamente Creado y Publicado') : Session::flash('message','Evento no Registrado algo salio mal');

        return redirect()->route('admin.event.index');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $event = Event::find($id);
        $establishments = Establishment::select('id','name','logo')
            ->where('establishments.user_id',Auth::user()->id)
            ->get();
        //dd($event);
        return view('dashboard.Admin.Events.edit', ['event'=>$event,'establishments'=>$establishments]);
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(EventRequest $request, $id)
    {
        $event = Event::find($id);

        $dataEvent = $request->get('event');

        if(empty($request->poster)){
            $publicity = $event->poster;
            $dataEvent['poster'] = $publicity;
        }else{
            //obtenemos el campo file definido en el formulario
            $posterFile = $request->file('poster');
            //dd($request);
            //obtenemos el nombre del archivo
            $namePoster = date('Y-m-d').rand(0,290).rand(4,892).$posterFile->getClientOriginalName();
            //indicamos que queremos guardar un nuevo archivo en el disco local
            \Storage::disk('local')->put($namePoster,  \File::get($posterFile));

            $dataEvent['poster'] = $namePoster;
        }

        $event->fill($dataEvent);

        $event->save();

        $event ? Session::flash('message','Evento Correctamente Actualizado') : Session::flash('message','Ups. Algo salio mal');

        return redirect()->route('admin.event.index');
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
