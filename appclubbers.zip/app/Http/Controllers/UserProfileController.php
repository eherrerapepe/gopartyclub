<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;
use App\Http\Requests\UserProfileRequest;
use App\Http\Controllers\Controller;
use App\User;
use App\ContactUser;
use App\Address;
use Auth;
use Session;

class UserProfileController extends Controller
{
    public function edit(){
        $user = User::with('contactUser','addressUserDj')->find(Auth::user()->id);
        //dd($user);
        return view('dashboard.editPerfil')->with(['user'=>$user,'contact'=>$user->contactUser,'address'=>$user->addressUserDj]);
    }

    public function update($id, UserProfileRequest $request){
        $user = User::find(Auth::user()->id);
        //buscamos el id de la tabla contcat_users mediante el id de la sesion iniciada actual
        $idContactUser = ContactUser::select('id')->where('user_id',Auth::user()->id)->first();
        $contact = ContactUser::find($idContactUser->id);
        $address = Address::find(Auth::user()->id);

        if($request->get('photo') != null){
            //obtenemos el campo file definido en el formulario
            $file = $request->file('photo');
            //dd($request);
            //obtenemos el nombre del archivo
            $nombre = date('Y-m-d').rand(0,290).rand(4,892).$file->getClientOriginalName();
            //indicamos que queremos guardar un nuevo archivo en el disco local
            \Storage::disk('local')->put($nombre,  \File::get($file));

            $dataUser = $request->get('users');
            $dataUser['photo'] = $nombre;
        }else{
            $dataUser = $request->get('users');
        }


        if($request->get('password') != null){
            $dataUser['password'] = \Hash::make($request->get('password'));
        }

        //dd($request->input('users.email'));
        //verificamos que se ha modificado el email para cambiarlo
        if($request->input('users.email') == null)
        {
            $dataUser['email'] = Auth::user()->email;
        }

        //actualisamos los datos del usuario
        $user->fill($dataUser);
        $user->save();

        //actualizamos los datos de contacto de dicho usuario
        $dataContact = $request->get('contact');
        $contact->fill($dataContact);
        $contact->save();

        //Actualizamos la address del usuario DJ
        if (Auth::user()->role === 'DJ') {
            $dataAddress = $request->get('address');
            $address->fill($dataAddress);
            $address->save();
        }

        Session::flash('message','Usuario Correctamente Actualizado');

        return redirect()->back();

    }
}
