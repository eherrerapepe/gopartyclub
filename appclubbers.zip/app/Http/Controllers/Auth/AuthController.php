<?php

namespace App\Http\Controllers\Auth;

use App\User;
use App\ContactUser;
use  App\Address;
use Validator;
use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\ThrottlesLogins;
use Illuminate\Foundation\Auth\AuthenticatesAndRegistersUsers;

class AuthController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Registration & Login Controller
    |--------------------------------------------------------------------------
    |
    | This controller handles the registration of new users, as well as the
    | authentication of existing users. By default, this controller uses
    | a simple trait to add these behaviors. Why don't you explore it?
    |
    */

    use AuthenticatesAndRegistersUsers, ThrottlesLogins;

    //Redirecionamos a la pagina de administracion
    protected $redirectPath = '/';

    /**
     * Create a new authentication controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('guest', ['except' => 'getLogout']);
    }

    /**
     * Get a validator for an incoming registration request.
     *
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    protected function validator(array $data)
    {
        return Validator::make($data, [
            'users.first_name' => 'required',
            'users.last_name' => 'required',
            'users.email' => 'required|email|max:255|unique:users',
            'users.role' => 'required',
            'contact.cell' => 'required',
            'password' => 'required|confirmed|min:6',
        ]);
    }

    /**
     * Create a new user instance after a valid registration.
     *
     * @param  array  $data
     * @return User
     */
    protected function create(array $data)
    {
        $dataUser = $data['users'];
        $dataUser['password'] = bcrypt($data['password']);

        $userRegister = User::create($dataUser);

        $dataContact = $data['contact'];
        $dataContact['user_id'] = $userRegister->id;

        ContactUser::create($dataContact);

        //Address
        $dataAddress = $data['address'];
        if(empty($dataAddress['address'])){
            $dataAddress['address'] = 'Direccion no registrada';
        }
        if(empty($dataAddress['city'])){
            $dataAddress['city'] = 'Ciudad no registrada';
        }
        if(empty($dataAddress['Country'])){
            $dataAddress['Country'] = 'País no registrado';
        }

        $dataAddress['user_id'] = $userRegister->id;

        Address::create($dataAddress);

        //falta imprimir el mensaje de error
        return $userRegister;
    }
}
