<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DjSong extends Model
{
    protected $table = 'dj_songs';
    protected $fillable = ['title','disco','song','date_time','user_id'];
}
