<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class Service extends Model
{
    protected $table = 'services';
    protected $fillable = ['name_service'];

    //Consultamos a que establecimeinto pertenece cada uno de los servicios
    public function establishmentServices(){
        return $this->belongsToMany('App\Establishment','establishment_services','services_id','establishments_id');
    }
}
