<?php

namespace App;

use Illuminate\Auth\Authenticatable;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Auth\Passwords\CanResetPassword;
use Illuminate\Foundation\Auth\Access\Authorizable;
use Illuminate\Contracts\Auth\Authenticatable as AuthenticatableContract;
use Illuminate\Contracts\Auth\Access\Authorizable as AuthorizableContract;
use Illuminate\Contracts\Auth\CanResetPassword as CanResetPasswordContract;

class User extends Model implements AuthenticatableContract,
                                    AuthorizableContract,
                                    CanResetPasswordContract
{
    use Authenticatable, Authorizable, CanResetPassword;

    /**
     * The database table used by the model.
     *
     * @var string
     */
    protected $table = 'users';

    /**
     * The attributes that are mass assignable.
     *
     * @var array
     */
    protected $fillable = ['photo','description','first_name', 'last_name', 'email', 'password','role','state'];

    /**
     * The attributes excluded from the model's JSON form.
     *
     * @var array
     */
    protected $hidden = ['password', 'remember_token'];


    /*
     * Retornamos una relacion uno a uno con los contactos
     */
    public function contactUser(){
        return $this->hasOne('App\ContactUser','user_id');
    }

    /*
     * Retornamos una relacion uno a uno de los address
     */
    public function addressUserDj(){
        return $this->hasOne('App\Address','user_id');
    }

    /*
     * Retornamos una relacion uno a valios con las mezclas
     */
    public function djSongs(){
        return $this->hasMany('App\DjSong','user_id');
    }
}
