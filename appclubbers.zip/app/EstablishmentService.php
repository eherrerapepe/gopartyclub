<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class EstablishmentService extends Model
{
    protected $table = 'establishment_services';
    protected $fillable = ['establishments_id','services_id'];
}
